//go:build windows

package main

import (
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"sort"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"
)

const (
	appName    = "Typora"
	appVersion = "4.20.0"

	WS_OVERLAPPEDWINDOW = 0x00CF0000
	WS_POPUP            = 0x80000000
	WS_VISIBLE          = 0x10000000
	WS_EX_TOOLWINDOW    = 0x00000080
	WS_CHILD            = 0x40000000
	WS_VSCROLL          = 0x00200000
	WS_HSCROLL          = 0x00100000
	WS_TABSTOP          = 0x00010000
	WS_CLIPCHILDREN     = 0x02000000
	ES_MULTILINE        = 0x0004
	ES_AUTOVSCROLL      = 0x0040
	ES_AUTOHSCROLL      = 0x0080
	ES_NOHIDESEL        = 0x0100
	ES_WANTRETURN       = 0x1000
	ES_READONLY         = 0x0800

	CW_USEDEFAULT    = 0x80000000
	SW_SHOW          = 5
	SW_HIDE          = 0
	SW_SHOWNORMAL    = 1
	SW_SHOWMAXIMIZED = 3

	WM_CREATE         = 0x0001
	WM_DESTROY        = 0x0002
	WM_SETREDRAW      = 0x000B
	WM_SIZE           = 0x0005
	WM_SETFOCUS       = 0x0007
	WM_KILLFOCUS      = 0x0008
	WM_CLOSE          = 0x0010
	WM_PAINT          = 0x000F
	WM_ERASEBKGND     = 0x0014
	WM_COMMAND        = 0x0111
	WM_NOTIFY         = 0x004E
	WM_TIMER          = 0x0113
	WM_MOUSEMOVE      = 0x0200
	WM_LBUTTONDOWN    = 0x0201
	WM_LBUTTONUP      = 0x0202
	WM_RBUTTONUP      = 0x0205
	WM_MBUTTONDOWN    = 0x0207
	WM_CAPTURECHANGED = 0x0215
	WM_EXITSIZEMOVE   = 0x0232
	WM_MOUSEWHEEL     = 0x020A
	WM_MOUSELEAVE     = 0x02A3
	WM_THEMECHANGED   = 0x031A
	WM_PRINTCLIENT    = 0x0318
	WM_SETFONT        = 0x0030
	WM_SETICON        = 0x0080
	WM_CTLCOLOREDIT   = 0x0133
	WM_APP_IO_RESULT  = 0x8001

	WM_SETTEXT       = 0x000C
	WM_GETTEXT       = 0x000D
	WM_GETTEXTLENGTH = 0x000E

	WM_KEYDOWN = 0x0100
	VK_LBUTTON = 0x01
	VK_CONTROL = 0x11
	VK_SHIFT   = 0x10
	VK_RETURN  = 0x0D
	VK_ESCAPE  = 0x1B
	VK_TAB     = 0x09
	VK_F1      = 0x70
	VK_F2      = 0x71

	EN_CHANGE    = 0x0300
	EN_KILLFOCUS = 0x0200
	EN_LINK      = 0x070B

	// RichEdit event masks / link formatting.
	ENM_LINK = 0x04000000
	CFM_LINK = 0x00000020
	CFE_LINK = 0x00000020

	EM_POSFROMCHAR        = 0x0426
	EM_SETBKGNDCOLOR      = 0x0443
	EM_SETEVENTMASK       = 0x0445
	EM_SETEDITSTYLE       = 0x04CC
	EM_SETMARGINS         = 0x00D3
	EM_SETSEL             = 0x00B1
	EM_LINESCROLL         = 0x00B6
	EM_STREAMIN           = 0x0449
	EM_SETREADONLY        = 0x00CF
	EM_SETCHARFORMAT      = 0x0444
	ENM_CHANGE            = 0x00000001
	SES_HYPERLINKTOOLTIPS = 0x00000008
	SES_NOFOCUSLINKNOTIFY = 0x00000020
	TME_LEAVE             = 0x00000002
	PRF_CLIENT            = 0x00000004
	EC_LEFTMARGIN         = 0x0001
	EC_RIGHTMARGIN        = 0x0002
	SF_RTF                = 0x0002
	SCF_SELECTION         = 0x0001
	SCF_ALL               = 0x0004
	CFM_BOLD              = 0x00000001
	CFM_ITALIC            = 0x00000002
	CFM_UNDERLINE         = 0x00000004
	CFM_STRIKEOUT         = 0x00000008
	CFM_BACKCOLOR         = 0x04000000
	CFE_BOLD              = 0x00000001
	CFE_ITALIC            = 0x00000002
	CFE_UNDERLINE         = 0x00000004
	CFE_STRIKEOUT         = 0x00000008
	CFM_SIZE              = 0x80000000
	CFM_COLOR             = 0x40000000
	CFM_FACE              = 0x20000000

	ICON_SMALL      = 0
	ICON_BIG        = 1
	IMAGE_ICON      = 1
	LR_LOADFROMFILE = 0x00000010
	LR_DEFAULTSIZE  = 0x00000040
	DI_NORMAL       = 0x0003

	IDC_ARROW    = 32512
	COLOR_WINDOW = 5

	DT_LEFT         = 0x00000000
	DT_CENTER       = 0x00000001
	DT_RIGHT        = 0x00000002
	DT_VCENTER      = 0x00000004
	DT_SINGLELINE   = 0x00000020
	DT_END_ELLIPSIS = 0x00008000
	DT_WORDBREAK    = 0x00000010
	DT_NOPREFIX     = 0x00000800
	TRANSPARENT     = 1
	PS_SOLID        = 0
	SRCCOPY         = 0x00CC0020

	MB_OK           = 0x00000000
	MB_OKCANCEL     = 0x00000001
	MB_YESNOCANCEL  = 0x00000003
	MB_YESNO        = 0x00000004
	MB_ICONQUESTION = 0x00000020
	MB_ICONWARNING  = 0x00000030
	IDOK            = 1
	IDCANCEL        = 2
	IDYES           = 6
	IDNO            = 7

	MF_STRING       = 0x00000000
	MF_SEPARATOR    = 0x00000800
	TPM_RIGHTBUTTON = 0x0002
	TPM_RETURNCMD   = 0x0100

	TIMER_AUTOSAVE      = 1
	TIMER_PREVIEW       = 2
	TIMER_RECOVERY      = 3
	TIMER_TOOLTIP       = 4
	TIMER_SMOOTH_SCROLL = 5

	IDC_EDITOR  = 2001
	IDC_PREVIEW = 2002
	IDC_RENAME  = 2003

	TOP_H     = 54
	TAB_H     = 42
	STATUS_H  = 28
	SIDEBAR_W = 238
)

type POINT struct{ X, Y int32 }
type SIZE struct{ Cx, Cy int32 }
type MSG struct {
	Hwnd           syscall.Handle
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             POINT
}
type RECT struct{ Left, Top, Right, Bottom int32 }
type WINDOWPLACEMENT struct {
	Length           uint32
	Flags            uint32
	ShowCmd          uint32
	PtMinPosition    POINT
	PtMaxPosition    POINT
	RcNormalPosition RECT
}
type MONITORINFO struct {
	CbSize    uint32
	RcMonitor RECT
	RcWork    RECT
	DwFlags   uint32
}
type TRACKMOUSEEVENT struct {
	CbSize      uint32
	DwFlags     uint32
	HwndTrack   syscall.Handle
	DwHoverTime uint32
}

type NMHDR struct {
	HwndFrom syscall.Handle
	IDFrom   uintptr
	Code     uint32
}
type CHARRANGE struct{ CpMin, CpMax int32 }
type ENLINK struct {
	Nmhdr  NMHDR
	Msg    uint32
	_      uint32 // align WPARAM on 64-bit Windows
	WParam uintptr
	LParam uintptr
	Chrg   CHARRANGE
}
type WNDCLASSEX struct {
	CbSize                                   uint32
	Style                                    uint32
	LpfnWndProc                              uintptr
	CbClsExtra, CbWndExtra                   int32
	HInstance, HIcon, HCursor, HbrBackground syscall.Handle
	LpszMenuName, LpszClassName              *uint16
	HIconSm                                  syscall.Handle
}
type PAINTSTRUCT struct {
	Hdc                  syscall.Handle
	FErase               int32
	RcPaint              RECT
	FRestore, FIncUpdate int32
	RgbReserved          [32]byte
}
type CHARFORMAT2 struct {
	CbSize          uint32
	DwMask          uint32
	DwEffects       uint32
	YHeight         int32
	YOffset         int32
	CrTextColor     uint32
	BCharSet        byte
	BPitchAndFamily byte
	SzFaceName      [32]uint16
	WWeight         uint16
	SSpacing        int16
	CrBackColor     uint32
	Lcid            uint32
	DwReserved      uint32
	SStyle          int16
	WKerning        uint16
	BUnderlineType  byte
	BAnimation      byte
	BRevAuthor      byte
	BReserved1      byte
}

type Document struct {
	ID          string
	Title       string
	Path        string
	BufferPath  string
	Content     string
	AutoCreated bool
	LastDiskMod int64
	Conflict    bool
	DiskMissing bool
	Revision    uint64
}

type palette struct {
	bg, panel, panel2, line, text, muted, accent, accentSoft, editorBg, statusGood, danger uint32
}

type App struct {
	hwnd, editor, preview, renameEdit           syscall.Handle
	iconBig, iconSmall, iconHeader              syscall.Handle
	fontUI, fontUISemibold, fontSmall, fontMono syscall.Handle
	editorBrush                                 syscall.Handle
	cfg                                         Config
	docs                                        []*Document
	active                                      int
	closed                                      []ClosedDoc
	sidebarFiles                                []string
	sidebarScroll                               int
	view                                        string
	suppress                                    bool
	saveStatus                                  string
	onboarding                                  bool
	tutorialStep                                int
	tutorialRevisit                             bool
	previewLinks                                []previewLink
	previewCodeBlocks                           []previewCodeBlock
	clientW, clientH                            int32
	renameOriginal                              string
	renameActive                                bool
	hover                                       string
	mouseTracking                               bool
	tabScroll                                   int32
	dragTab                                     int
	dragStartX, dragStartY                      int32
	dragVisualX                                 int32
	dragging, dragMoved                         bool
	sidebarDrag                                 int
	sidebarDragStartY, sidebarDragVisualY       int32
	sidebarDragging, sidebarDragMoved           bool
	contextVisible                              bool
	contextHwnd                                 syscall.Handle
	contextKind                                 string
	contextPath                                 string
	contextTab                                  int
	contextX, contextY                          int32
	contextHover                                int
	tooltipVisible                              bool
	tooltipTarget                               string
	mouseX, mouseY                              int32
	shortcutsVisible                            bool
	scrollTarget                                syscall.Handle
	smoothScrollRemaining                       int
	wheelRemainder                              int
}

var app App
var oldEditorWndProc uintptr
var oldPreviewWndProc uintptr
var richEditSubclassCallback uintptr
var errExternalChange = errors.New("file changed outside Typora")

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	msftedit = syscall.NewLazyDLL("Msftedit.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")
	uxtheme  = syscall.NewLazyDLL("uxtheme.dll")

	procRegisterClassEx     = user32.NewProc("RegisterClassExW")
	procCreateWindowEx      = user32.NewProc("CreateWindowExW")
	procDestroyWindow       = user32.NewProc("DestroyWindow")
	procDefWindowProc       = user32.NewProc("DefWindowProcW")
	procShowWindow          = user32.NewProc("ShowWindow")
	procUpdateWindow        = user32.NewProc("UpdateWindow")
	procGetMessage          = user32.NewProc("GetMessageW")
	procTranslateMessage    = user32.NewProc("TranslateMessage")
	procDispatchMessage     = user32.NewProc("DispatchMessageW")
	procPostQuitMessage     = user32.NewProc("PostQuitMessage")
	procPostMessage         = user32.NewProc("PostMessageW")
	procLoadCursor          = user32.NewProc("LoadCursorW")
	procSendMessage         = user32.NewProc("SendMessageW")
	procSetWindowText       = user32.NewProc("SetWindowTextW")
	procSetWindowLongPtr    = user32.NewProc("SetWindowLongPtrW")
	procCallWindowProc      = user32.NewProc("CallWindowProcW")
	procGetWindowPlacement  = user32.NewProc("GetWindowPlacement")
	procMonitorFromRect     = user32.NewProc("MonitorFromRect")
	procGetMonitorInfo      = user32.NewProc("GetMonitorInfoW")
	procGetWindowTextLength = user32.NewProc("GetWindowTextLengthW")
	procGetWindowText       = user32.NewProc("GetWindowTextW")
	procMoveWindow          = user32.NewProc("MoveWindow")
	procGetClientRect       = user32.NewProc("GetClientRect")
	procGetDC               = user32.NewProc("GetDC")
	procReleaseDC           = user32.NewProc("ReleaseDC")
	procScreenToClient      = user32.NewProc("ScreenToClient")
	procClientToScreen      = user32.NewProc("ClientToScreen")
	procInvalidateRect      = user32.NewProc("InvalidateRect")
	procTrackMouseEvent     = user32.NewProc("TrackMouseEvent")
	procSetCapture          = user32.NewProc("SetCapture")
	procReleaseCapture      = user32.NewProc("ReleaseCapture")
	procCreatePopupMenu     = user32.NewProc("CreatePopupMenu")
	procAppendMenu          = user32.NewProc("AppendMenuW")
	procTrackPopupMenu      = user32.NewProc("TrackPopupMenu")
	procDestroyMenu         = user32.NewProc("DestroyMenu")
	procRedrawWindow        = user32.NewProc("RedrawWindow")
	procBeginPaint          = user32.NewProc("BeginPaint")
	procEndPaint            = user32.NewProc("EndPaint")
	procFillRect            = user32.NewProc("FillRect")
	procDrawText            = user32.NewProc("DrawTextW")
	procSetFocus            = user32.NewProc("SetFocus")
	procSetTimer            = user32.NewProc("SetTimer")
	procKillTimer           = user32.NewProc("KillTimer")
	procGetKeyState         = user32.NewProc("GetKeyState")
	procMessageBox          = user32.NewProc("MessageBoxW")
	procLoadImage           = user32.NewProc("LoadImageW")
	procDrawIconEx          = user32.NewProc("DrawIconEx")
	procSetProcessDPIAware  = user32.NewProc("SetProcessDPIAware")

	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procRectangle              = gdi32.NewProc("Rectangle")
	procCreateFont             = gdi32.NewProc("CreateFontW")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procGetTextExtentPoint32   = gdi32.NewProc("GetTextExtentPoint32W")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procSaveDC                 = gdi32.NewProc("SaveDC")
	procRestoreDC              = gdi32.NewProc("RestoreDC")
	procIntersectClipRect      = gdi32.NewProc("IntersectClipRect")

	procGetModuleHandle       = kernel32.NewProc("GetModuleHandleW")
	procShellExecuteW         = shell32.NewProc("ShellExecuteW")
	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
	procSetWindowTheme        = uxtheme.NewProc("SetWindowTheme")
)

func wstr(s string) *uint16      { p, _ := syscall.UTF16PtrFromString(s); return p }
func rgb(r, g, b byte) uint32    { return uint32(r) | uint32(g)<<8 | uint32(b)<<16 }
func loWord(v uintptr) uint16    { return uint16(v & 0xffff) }
func hiWord(v uintptr) uint16    { return uint16((v >> 16) & 0xffff) }
func signedWord(v uintptr) int32 { return int32(int16(v & 0xffff)) }
func send(hwnd syscall.Handle, msg uint32, wparam, lparam uintptr) uintptr {
	r, _, _ := procSendMessage.Call(uintptr(hwnd), uintptr(msg), wparam, lparam)
	return r
}
func setText(hwnd syscall.Handle, s string) {
	procSetWindowText.Call(uintptr(hwnd), uintptr(unsafe.Pointer(wstr(s))))
}
func getText(hwnd syscall.Handle) string {
	l, _, _ := procGetWindowTextLength.Call(uintptr(hwnd))
	if l == 0 {
		return ""
	}
	b := make([]uint16, l+1)
	procGetWindowText.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&b[0])), uintptr(l+1))
	return syscall.UTF16ToString(b)
}
func invalidate() {
	if app.hwnd != 0 {
		// Never request a background erase for our custom-painted shell. The shell
		// paints every invalid pixel itself; erasing first is what caused the visible
		// flash/flicker in earlier native builds.
		procInvalidateRect.Call(uintptr(app.hwnd), 0, 0)
	}
}

func invalidateRegion(r RECT) {
	if app.hwnd == 0 {
		return
	}
	procInvalidateRect.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(&r)), 0)
}

func invalidateStatus() {
	if app.clientH <= 0 {
		return
	}
	invalidateRegion(RECT{0, app.clientH - STATUS_H, app.clientW, app.clientH})
}

func invalidateSidebar() {
	if !app.cfg.Sidebar {
		return
	}
	invalidateRegion(RECT{0, TOP_H, SIDEBAR_W, app.clientH - STATUS_H})
}

func colors() palette {
	if app.cfg.Theme == "light" {
		return palette{rgb(247, 248, 250), rgb(255, 255, 255), rgb(242, 244, 248), rgb(224, 227, 234), rgb(31, 34, 40), rgb(112, 118, 130), rgb(73, 101, 220), rgb(230, 235, 255), rgb(255, 255, 255), rgb(30, 150, 92), rgb(210, 70, 70)}
	}
	return palette{rgb(18, 21, 27), rgb(23, 27, 34), rgb(28, 32, 40), rgb(43, 48, 59), rgb(238, 240, 245), rgb(143, 151, 166), rgb(111, 143, 255), rgb(38, 46, 74), rgb(20, 24, 30), rgb(92, 214, 151), rgb(255, 105, 105)}
}

func createFont(size int32, weight int32, face string) syscall.Handle {
	r, _, _ := procCreateFont.Call(uintptr(-size), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(wstr(face))))
	return syscall.Handle(r)
}

func createChild(class string, style uint32, id int) syscall.Handle {
	hInst, _, _ := procGetModuleHandle.Call(0)
	r, _, _ := procCreateWindowEx.Call(0, uintptr(unsafe.Pointer(wstr(class))), uintptr(unsafe.Pointer(wstr(""))), uintptr(style), 0, 0, 10, 10, uintptr(app.hwnd), uintptr(id), hInst, 0)
	return syscall.Handle(r)
}

func setEditorStyle() {
	p := colors()
	if app.editorBrush != 0 {
		procDeleteObject.Call(uintptr(app.editorBrush))
		app.editorBrush = 0
	}
	if b, _, _ := procCreateSolidBrush.Call(uintptr(p.editorBg)); b != 0 {
		app.editorBrush = syscall.Handle(b)
	}
	send(app.editor, EM_SETBKGNDCOLOR, 0, uintptr(p.editorBg))
	send(app.preview, EM_SETBKGNDCOLOR, 0, uintptr(p.editorBg))
	var cf CHARFORMAT2
	cf.CbSize = uint32(unsafe.Sizeof(cf))
	cf.DwMask = CFM_COLOR | CFM_FACE | CFM_SIZE
	cf.CrTextColor = p.text
	cf.YHeight = 220
	face := utf16.Encode([]rune("Cascadia Mono"))
	copy(cf.SzFaceName[:], face)
	send(app.editor, EM_SETCHARFORMAT, SCF_ALL, uintptr(unsafe.Pointer(&cf)))
	send(app.editor, EM_SETMARGINS, EC_LEFTMARGIN|EC_RIGHTMARGIN, uintptr(24|(24<<16)))
	send(app.preview, EM_SETMARGINS, EC_LEFTMARGIN|EC_RIGHTMARGIN, uintptr(28|(28<<16)))
	send(app.editor, EM_SETEVENTMASK, 0, ENM_CHANGE)
	send(app.preview, EM_SETEVENTMASK, 0, ENM_LINK)
	// ENM_LINK alone only guarantees notifications once a link/control has focus.
	// Keep hyperlinks clickable on the first click and show their target tooltip.
	send(app.preview, EM_SETEDITSTYLE, SES_NOFOCUSLINKNOTIFY|SES_HYPERLINKTOOLTIPS, SES_NOFOCUSLINKNOTIFY|SES_HYPERLINKTOOLTIPS)
	dark := int32(0)
	if app.cfg.Theme != "light" {
		dark = 1
	}
	if app.hwnd != 0 {
		procDwmSetWindowAttribute.Call(uintptr(app.hwnd), 20, uintptr(unsafe.Pointer(&dark)), unsafe.Sizeof(dark))
	}
	// RichEdit owns its non-client scrollbars. Theme the controls themselves so
	// Windows 11 does not drop a bright legacy scrollbar into an otherwise dark UI.
	// In light mode, return them to the normal Explorer theme.
	theme := "Explorer"
	if dark != 0 {
		theme = "DarkMode_Explorer"
	}
	for _, h := range []syscall.Handle{app.editor, app.preview, app.renameEdit} {
		if h != 0 {
			procSetWindowTheme.Call(uintptr(h), uintptr(unsafe.Pointer(wstr(theme))), 0)
			send(h, WM_THEMECHANGED, 0, 0)
		}
	}
}

func message(text, title string, flags uintptr) int {
	r, _, _ := procMessageBox.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(wstr(text))), uintptr(unsafe.Pointer(wstr(title))), flags)
	return int(r)
}

func activeDoc() *Document {
	if app.active >= 0 && app.active < len(app.docs) {
		return app.docs[app.active]
	}
	return nil
}
func syncEditorToDoc() {
	if app.suppress {
		return
	}
	if d := activeDoc(); d != nil {
		d.Content = getText(app.editor)
	}
}
func setEditorFromDoc() {
	d := activeDoc()
	app.suppress = true
	if d != nil {
		setText(app.editor, d.Content)
	} else {
		setText(app.editor, "")
	}
	app.suppress = false
	updateWindowTitle()
	schedulePreview()
	invalidate()
}

func fileModNano(path string) int64 {
	if st, err := os.Stat(path); err == nil {
		return st.ModTime().UnixNano()
	}
	return 0
}
func writeBuffer(d *Document) error {
	if d.BufferPath == "" {
		d.BufferPath = bufferPath(d.ID)
	}
	return atomicWrite(d.BufferPath, []byte(d.Content), 0644)
}

func saveDoc(d *Document, force bool) error {
	if d == nil || d.Path == "" {
		return nil
	}
	if !force && d.LastDiskMod != 0 {
		now := fileModNano(d.Path)
		if now != 0 && now != d.LastDiskMod {
			return errExternalChange
		}
	}
	if err := writeBuffer(d); err != nil {
		return err
	}
	if err := atomicWrite(d.Path, []byte(d.Content), 0644); err != nil {
		return err
	}
	d.LastDiskMod = fileModNano(d.Path)
	d.Conflict = false
	return nil
}

func sessionSnapshot() Session {
	s := Session{Active: app.active}
	for _, d := range app.docs {
		s.Docs = append(s.Docs, SessionDoc{ID: d.ID, Title: d.Title, Path: d.Path, BufferPath: d.BufferPath, AutoCreated: d.AutoCreated, LastDiskMod: d.LastDiskMod, DiskMissing: d.DiskMissing})
	}
	return s
}

func persistSessionAsync() {
	queueSessionPersist(sessionSnapshot(), app.closed)
}

func persistSessionNow() {
	syncEditorToDoc()
	if d := activeDoc(); d != nil {
		// Recovery buffers live on local storage and are intentionally cheap to update.
		_ = writeBuffer(d)
	}
	_ = saveSession(sessionSnapshot())
	_ = saveClosed(app.closed)
}

func scheduleAutosave() {
	procKillTimer.Call(uintptr(app.hwnd), TIMER_AUTOSAVE)
	procSetTimer.Call(uintptr(app.hwnd), TIMER_AUTOSAVE, 600, 0)
}
func schedulePreview() {
	if app.view == "edit" {
		return
	}
	procKillTimer.Call(uintptr(app.hwnd), TIMER_PREVIEW)
	procSetTimer.Call(uintptr(app.hwnd), TIMER_PREVIEW, 180, 0)
}
func scheduleRecovery() {
	procKillTimer.Call(uintptr(app.hwnd), TIMER_RECOVERY)
	procSetTimer.Call(uintptr(app.hwnd), TIMER_RECOVERY, 100, 0)
}
func saveActive(force bool) {
	syncEditorToDoc()
	d := activeDoc()
	if d == nil {
		return
	}
	if d.DiskMissing && !force {
		app.saveStatus = "Deleted externally • Ctrl+S to restore or Ctrl+Shift+S for Save As"
		invalidateStatus()
		return
	}
	queueDiskSave(d, force, false)
	app.saveStatus = "Saving…"
	invalidate()
}

func saveAll() {
	syncEditorToDoc()
	// Never block WM_CLOSE on external/slow drives. Recovery is local and synchronous,
	// so every tab can be restored even if the real-file autosave was still in flight.
	for _, d := range app.docs {
		_ = writeBuffer(d)
	}
	persistSessionNow()
}

func resolveManualSave() {
	d := activeDoc()
	if d == nil {
		return
	}
	syncEditorToDoc()
	if d.DiskMissing {
		ans := message("This file was deleted outside Typora.\n\nRecreate it at its previous location?\n\nChoose No to keep the tab only; use Ctrl+Shift+S to save it somewhere else.", "File deleted outside Typora", MB_YESNO|MB_ICONWARNING)
		if ans != IDYES {
			app.saveStatus = "Deleted externally • not restored"
			invalidateStatus()
			return
		}
		queueDiskSave(d, true, true)
		app.saveStatus = "Restoring…"
		invalidateStatus()
		return
	}
	queueDiskSave(d, false, true)
	app.saveStatus = "Saving…"
	invalidate()
}

func ensureDefaultFolder() {
	if app.cfg.DefaultFolder == "" {
		app.cfg.DefaultFolder = defaultNotesFolder()
	}
	_ = os.MkdirAll(app.cfg.DefaultFolder, 0755)
}

func newDocument() {
	if !app.cfg.Onboarded {
		return
	}
	syncEditorToDoc()
	ensureDefaultFolder()
	title := nextUntitled(app.cfg.DefaultFolder)
	path := filepath.Join(app.cfg.DefaultFolder, title+".md")
	d := &Document{ID: randomID(), Title: title, Path: path, AutoCreated: true}
	d.BufferPath = bufferPath(d.ID)
	_ = writeBuffer(d)
	app.docs = append(app.docs, d)
	app.active = len(app.docs) - 1
	app.view = "edit"
	queueDiskSave(d, true, false)
	setEditorFromDoc()
	persistSessionNow()
	refreshSidebar()
	layout()
	beginRename()
	app.saveStatus = "Saved"
	invalidate()
}

func renameCurrent(title string) {
	d := activeDoc()
	if d == nil {
		return
	}
	title = cleanTitle(title)
	if title == "" {
		title = d.Title
		if title == "" {
			title = nextUntitled(app.cfg.DefaultFolder)
		}
	}
	folder := app.cfg.DefaultFolder
	if !d.AutoCreated && filepath.Dir(d.Path) != folder {
		return
	}
	title = uniqueTitle(folder, title, d.Path)
	newPath := filepath.Join(folder, title+".md")
	old := d.Path
	d.Title = title
	d.Path = newPath
	d.LastDiskMod = 0
	d.DiskMissing = false
	_ = writeBuffer(d)
	if !strings.EqualFold(filepath.Clean(old), filepath.Clean(newPath)) {
		queueRenameSave(d, old)
	} else {
		queueDiskSave(d, true, false)
	}
	persistSessionNow()
	refreshSidebar()
	updateWindowTitle()
	app.saveStatus = "Saving…"
	invalidate()
}

func beginRename() {
	d := activeDoc()
	if d == nil {
		return
	}
	r := tabRect(app.active)
	if app.renameEdit == 0 {
		app.renameEdit = createChild("EDIT", WS_CHILD|WS_TABSTOP|ES_AUTOHSCROLL, IDC_RENAME)
		send(app.renameEdit, WM_SETFONT, uintptr(app.fontUI), 1)
	}
	app.renameOriginal = d.Title
	app.renameActive = true
	setText(app.renameEdit, d.Title)
	procMoveWindow.Call(uintptr(app.renameEdit), uintptr(r.Left+12), uintptr(r.Top+8), uintptr(max32(70, r.Right-r.Left-40)), 26, 1)
	procShowWindow.Call(uintptr(app.renameEdit), SW_SHOW)
	send(app.renameEdit, EM_SETSEL, 0, ^uintptr(0))
	procSetFocus.Call(uintptr(app.renameEdit))
}
func commitRename() {
	if app.renameEdit == 0 || !app.renameActive {
		return
	}
	app.renameActive = false
	title := getText(app.renameEdit)
	procShowWindow.Call(uintptr(app.renameEdit), SW_HIDE)
	renameCurrent(title)
	procSetFocus.Call(uintptr(app.editor))
}
func cancelRename() {
	if app.renameEdit == 0 || !app.renameActive {
		return
	}
	app.renameActive = false
	procShowWindow.Call(uintptr(app.renameEdit), SW_HIDE)
	procSetFocus.Call(uintptr(app.editor))
	invalidate()
}

func switchTab(i int) {
	if i < 0 || i >= len(app.docs) || i == app.active {
		return
	}
	saveActive(false)
	app.active = i
	setEditorFromDoc()
	layout()
	invalidate()
}
func closeTab(i int) {
	if i < 0 || i >= len(app.docs) {
		return
	}
	syncEditorToDoc()
	d := app.docs[i]
	if app.cfg.ConfirmTabClose && strings.TrimSpace(d.Content) != "" {
		closeIt, neverAsk := confirmCloseTab(app.hwnd, d.Title)
		if neverAsk {
			app.cfg.ConfirmTabClose = false
			_ = saveConfig(app.cfg)
		}
		if !closeIt {
			return
		}
	}
	_ = writeBuffer(d)
	queueDiskSave(d, false, false)
	app.closed = append([]ClosedDoc{{SessionDoc: SessionDoc{ID: d.ID, Title: d.Title, Path: d.Path, BufferPath: d.BufferPath, AutoCreated: d.AutoCreated, LastDiskMod: d.LastDiskMod, DiskMissing: d.DiskMissing}, ClosedAt: time.Now().Unix()}}, app.closed...)
	if len(app.closed) > 20 {
		app.closed = app.closed[:20]
	}
	app.docs = append(app.docs[:i], app.docs[i+1:]...)
	if len(app.docs) == 0 {
		app.active = -1
		setEditorFromDoc()
		app.saveStatus = "Ready"
		persistSessionNow()
		layout()
		invalidate()
		return
	}
	if app.active >= len(app.docs) {
		app.active = len(app.docs) - 1
	} else if i < app.active {
		app.active--
	}
	setEditorFromDoc()
	persistSessionNow()
	layout()
	invalidate()
}
func reopenClosed() {
	if len(app.closed) == 0 {
		return
	}
	c := app.closed[0]
	app.closed = app.closed[1:]
	content, _ := os.ReadFile(c.BufferPath)
	if len(content) == 0 && c.Path != "" {
		content, _ = os.ReadFile(c.Path)
	}
	d := &Document{ID: c.ID, Title: c.Title, Path: c.Path, BufferPath: c.BufferPath, Content: string(content), AutoCreated: c.AutoCreated, LastDiskMod: fileModNano(c.Path), DiskMissing: c.DiskMissing || (c.LastDiskMod != 0 && fileModNano(c.Path) == 0)}
	app.docs = append(app.docs, d)
	app.active = len(app.docs) - 1
	setEditorFromDoc()
	persistSessionNow()
	layout()
	invalidate()
}

func removeOpenDocsForPath(path string) {
	path = filepath.Clean(path)
	oldActive := app.active
	newActive := oldActive
	activeRemoved := false
	kept := make([]*Document, 0, len(app.docs))
	for i, d := range app.docs {
		if d.Path != "" && strings.EqualFold(filepath.Clean(d.Path), path) {
			cancelDocIO(d.ID)
			_ = os.Remove(d.BufferPath)
			if i < oldActive {
				newActive--
			}
			if i == oldActive {
				activeRemoved = true
			}
			continue
		}
		kept = append(kept, d)
	}
	app.docs = kept
	// A deleted note is intentionally not kept in the recently-closed stack.
	filtered := app.closed[:0]
	for _, c := range app.closed {
		if c.Path == "" || !strings.EqualFold(filepath.Clean(c.Path), path) {
			filtered = append(filtered, c)
		}
	}
	app.closed = filtered
	_ = saveClosed(app.closed)
	if len(app.docs) == 0 {
		app.active = -1
		setEditorFromDoc()
		app.saveStatus = "Ready"
		persistSessionNow()
		layout()
		invalidate()
		return
	}
	if activeRemoved && newActive >= len(app.docs) {
		newActive = len(app.docs) - 1
	}
	if newActive < 0 {
		newActive = 0
	}
	app.active = newActive
	setEditorFromDoc()
	persistSessionNow()
	layout()
	invalidate()
}

func deleteNotePath(path string) {
	if path == "" {
		return
	}
	path = filepath.Clean(path)
	title := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	if !confirmDeleteNote(app.hwnd, title) {
		return
	}
	// Cancel any queued autosave before asking Windows to move the real file.
	for _, d := range app.docs {
		if d.Path != "" && strings.EqualFold(filepath.Clean(d.Path), path) {
			cancelDocIO(d.ID)
		}
	}
	if err := recycleFile(app.hwnd, path); err != nil {
		if err.Error() != "delete cancelled" {
			message(err.Error(), "Could not delete note", MB_OK|MB_ICONWARNING)
		}
		return
	}
	removeOpenDocsForPath(path)
	refreshSidebar()
}

func contextMenuCommand(items []struct {
	id    uintptr
	label string
}, x, y int32) uintptr {
	menu, _, _ := procCreatePopupMenu.Call()
	if menu == 0 {
		return 0
	}
	defer procDestroyMenu.Call(menu)
	for _, item := range items {
		if item.id == 0 {
			procAppendMenu.Call(menu, MF_SEPARATOR, 0, 0)
			continue
		}
		procAppendMenu.Call(menu, MF_STRING, item.id, uintptr(unsafe.Pointer(wstr(item.label))))
	}
	pt := POINT{X: x, Y: y}
	procClientToScreen.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(&pt)))
	cmd, _, _ := procTrackPopupMenu.Call(menu, TPM_RIGHTBUTTON|TPM_RETURNCMD, uintptr(pt.X), uintptr(pt.Y), 0, uintptr(app.hwnd), 0)
	return cmd
}

type contextEntry struct {
	Label     string
	Action    string
	Separator bool
	Danger    bool
}

func contextEntries() []contextEntry {
	switch app.contextKind {
	case "tab":
		return []contextEntry{
			{Label: "Rename", Action: "rename"},
			{Label: "Close tab", Action: "close"},
			{Separator: true},
			{Label: "Open in Explorer", Action: "explorer"},
			{Label: "Delete note…", Action: "delete", Danger: true},
		}
	case "sidebar":
		return []contextEntry{
			{Label: "Open", Action: "open"},
			{Label: "Open in Explorer", Action: "explorer"},
			{Separator: true},
			{Label: "Sort notes A–Z", Action: "sortaz"},
			{Separator: true},
			{Label: "Delete note…", Action: "delete", Danger: true},
		}
	case "sidebar-root":
		return []contextEntry{
			{Label: "Open folder in Explorer", Action: "explorer"},
			{Label: "Sort notes A–Z", Action: "sortaz"},
		}
	}
	return nil
}

func contextMenuSize() (int32, int32) {
	h := int32(16)
	for _, e := range contextEntries() {
		if e.Separator {
			h += 9
		} else {
			h += 32
		}
	}
	return 206, h
}

func contextMenuRect() RECT {
	w, h := contextMenuSize()
	x, y := app.contextX, app.contextY
	if x+w > app.clientW-8 {
		x = app.clientW - w - 8
	}
	if y+h > app.clientH-STATUS_H-8 {
		y = app.clientH - STATUS_H - h - 8
	}
	if x < 8 {
		x = 8
	}
	if y < TOP_H+4 {
		y = TOP_H + 4
	}
	return RECT{x, y, x + w, y + h}
}

func contextItemRect(index int) (RECT, bool) {
	r := contextMenuRect()
	y := r.Top + 8
	for i, e := range contextEntries() {
		if e.Separator {
			y += 9
			continue
		}
		rr := RECT{r.Left + 6, y, r.Right - 6, y + 32}
		if i == index {
			return rr, true
		}
		y += 32
	}
	return RECT{}, false
}

func contextHit(x, y int32) int {
	if !app.contextVisible || !contains(contextMenuRect(), x, y) {
		return -1
	}
	for i, e := range contextEntries() {
		if e.Separator {
			continue
		}
		if r, ok := contextItemRect(i); ok && contains(r, x, y) {
			return i
		}
	}
	return -1
}

func openInExplorer(path string) {
	if path == "" {
		path = app.cfg.DefaultFolder
	}
	path = filepath.Clean(path)
	if st, err := os.Stat(path); err == nil && st.IsDir() {
		procShellExecuteW.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(wstr("open"))), uintptr(unsafe.Pointer(wstr("explorer.exe"))), uintptr(unsafe.Pointer(wstr("\""+path+"\""))), 0, SW_SHOWNORMAL)
		return
	}
	params := "/select,\"" + path + "\""
	procShellExecuteW.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(wstr("open"))), uintptr(unsafe.Pointer(wstr("explorer.exe"))), uintptr(unsafe.Pointer(wstr(params))), 0, SW_SHOWNORMAL)
}

func closeContextMenu() {
	if app.contextHwnd != 0 {
		h := app.contextHwnd
		app.contextHwnd = 0
		procDestroyWindow.Call(uintptr(h))
	}
	app.contextVisible = false
	app.contextKind = ""
	app.contextPath = ""
	app.contextTab = -1
	app.contextHover = -1
}

func executeContext(index int) {
	entries := contextEntries()
	if index < 0 || index >= len(entries) || entries[index].Separator {
		closeContextMenu()
		return
	}
	action := entries[index].Action
	kind := app.contextKind
	path := app.contextPath
	tab := app.contextTab
	if app.contextHwnd != 0 {
		h := app.contextHwnd
		app.contextHwnd = 0
		procDestroyWindow.Call(uintptr(h))
	}
	app.contextVisible = false
	app.contextHover = -1
	switch action {
	case "rename":
		if kind == "tab" && tab >= 0 && tab < len(app.docs) {
			switchTab(tab)
			beginRename()
		}
	case "close":
		if kind == "tab" && tab >= 0 && tab < len(app.docs) {
			closeTab(tab)
		}
	case "open":
		if path != "" {
			openFile(path)
		}
	case "explorer":
		openInExplorer(path)
	case "sortaz":
		sortSidebarAlphabetical()
	case "delete":
		if path != "" {
			deleteNotePath(path)
		}
	}
	invalidate()
}

func paintContextMenu(hdc syscall.Handle) {
	if !app.contextVisible || app.onboarding || app.shortcutsVisible {
		return
	}
	p := colors()
	r := contextMenuRect()
	shadow := RECT{r.Left + 3, r.Top + 4, r.Right + 3, r.Bottom + 4}
	shadowColor := rgb(8, 10, 14)
	if app.cfg.Theme == "light" {
		shadowColor = rgb(205, 208, 216)
	}
	roundFill(hdc, shadow, shadowColor, 9)
	roundFill(hdc, r, p.panel2, 9)
	// Thin edge keeps the menu distinct from editor surfaces.
	frame := r
	frame.Left++
	frame.Top++
	frame.Right--
	frame.Bottom--
	// A simple inner line is enough without introducing another GDI object helper.
	fill(hdc, RECT{frame.Left + 7, frame.Top, frame.Right - 7, frame.Top + 1}, p.line)
	fill(hdc, RECT{frame.Left + 7, frame.Bottom - 1, frame.Right - 7, frame.Bottom}, p.line)
	y := r.Top + 8
	for i, e := range contextEntries() {
		if e.Separator {
			fill(hdc, RECT{r.Left + 12, y + 4, r.Right - 12, y + 5}, p.line)
			y += 9
			continue
		}
		rr := RECT{r.Left + 6, y, r.Right - 6, y + 32}
		if app.hover == fmt.Sprintf("context:%d", i) {
			hoverColor := rgb(54, 64, 82)
			if app.cfg.Theme == "light" {
				hoverColor = rgb(224, 231, 247)
			}
			roundFill(hdc, rr, hoverColor, 7)
		}
		fg := p.text
		if e.Danger {
			fg = p.danger
		}
		drawText(hdc, e.Label, RECT{rr.Left + 12, rr.Top, rr.Right - 10, rr.Bottom}, app.fontUI, fg, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		y += 32
	}
}

func contextPopupItemRect(index int) (RECT, bool) {
	w, _ := contextMenuSize()
	y := int32(8)
	for i, e := range contextEntries() {
		if e.Separator {
			y += 9
			continue
		}
		rr := RECT{6, y, w - 6, y + 32}
		if i == index {
			return rr, true
		}
		y += 32
	}
	return RECT{}, false
}

func contextPopupHit(x, y int32) int {
	w, h := contextMenuSize()
	if x < 0 || y < 0 || x >= w || y >= h {
		return -1
	}
	for i, e := range contextEntries() {
		if e.Separator {
			continue
		}
		if r, ok := contextPopupItemRect(i); ok && contains(r, x, y) {
			return i
		}
	}
	return -1
}

func paintContextPopup(hwnd syscall.Handle) {
	var ps PAINTSTRUCT
	hdc, _, _ := procBeginPaint.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&ps)))
	if hdc == 0 {
		return
	}
	defer procEndPaint.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&ps)))
	p := colors()
	w, h := contextMenuSize()
	fill(syscall.Handle(hdc), RECT{0, 0, w, h}, p.panel2)
	// Thin inset edge keeps the popup crisp against both dark and light documents.
	fill(syscall.Handle(hdc), RECT{0, 0, w, 1}, p.line)
	fill(syscall.Handle(hdc), RECT{0, h - 1, w, h}, p.line)
	fill(syscall.Handle(hdc), RECT{0, 0, 1, h}, p.line)
	fill(syscall.Handle(hdc), RECT{w - 1, 0, w, h}, p.line)
	y := int32(8)
	for i, e := range contextEntries() {
		if e.Separator {
			fill(syscall.Handle(hdc), RECT{12, y + 4, w - 12, y + 5}, p.line)
			y += 9
			continue
		}
		rr := RECT{6, y, w - 6, y + 32}
		if app.contextHover == i {
			hoverColor := rgb(58, 70, 92)
			if app.cfg.Theme == "light" {
				hoverColor = rgb(218, 227, 247)
			}
			roundFill(syscall.Handle(hdc), rr, hoverColor, 7)
		}
		fg := p.text
		if e.Danger {
			fg = p.danger
		}
		drawText(syscall.Handle(hdc), e.Label, RECT{rr.Left + 12, rr.Top, rr.Right - 10, rr.Bottom}, app.fontUI, fg, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		y += 32
	}
}

func contextMenuWndProc(hwnd syscall.Handle, msg uint32, wparam, lparam uintptr) uintptr {
	switch msg {
	case WM_PAINT:
		paintContextPopup(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_MOUSEMOVE:
		x, y := signedWord(lparam), int32(int16((lparam>>16)&0xffff))
		next := contextPopupHit(x, y)
		if next != app.contextHover {
			app.contextHover = next
			procInvalidateRect.Call(uintptr(hwnd), 0, 0)
		}
		tme := TRACKMOUSEEVENT{CbSize: uint32(unsafe.Sizeof(TRACKMOUSEEVENT{})), DwFlags: TME_LEAVE, HwndTrack: hwnd}
		procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		return 0
	case WM_MOUSELEAVE:
		if app.contextHover != -1 {
			app.contextHover = -1
			procInvalidateRect.Call(uintptr(hwnd), 0, 0)
		}
		return 0
	case WM_LBUTTONUP:
		x, y := signedWord(lparam), int32(int16((lparam>>16)&0xffff))
		if i := contextPopupHit(x, y); i >= 0 {
			executeContext(i)
		} else {
			closeContextMenu()
		}
		return 0
	case WM_KILLFOCUS:
		if app.contextHwnd == hwnd {
			procDestroyWindow.Call(uintptr(hwnd))
		}
		return 0
	case WM_DESTROY:
		if app.contextHwnd == hwnd {
			app.contextHwnd = 0
			app.contextVisible = false
			app.contextHover = -1
			app.contextKind = ""
			app.contextPath = ""
			app.contextTab = -1
		}
		return 0
	}
	r, _, _ := procDefWindowProc.Call(uintptr(hwnd), uintptr(msg), wparam, lparam)
	return r
}

func showContextPopup(x, y int32) {
	if app.contextHwnd != 0 {
		procDestroyWindow.Call(uintptr(app.contextHwnd))
		app.contextHwnd = 0
	}
	w, h := contextMenuSize()
	pt := POINT{X: x, Y: y}
	procClientToScreen.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(&pt)))
	rc := RECT{pt.X, pt.Y, pt.X + w, pt.Y + h}
	hmon, _, _ := procMonitorFromRect.Call(uintptr(unsafe.Pointer(&rc)), 2) // MONITOR_DEFAULTTONEAREST
	if hmon != 0 {
		mi := MONITORINFO{CbSize: uint32(unsafe.Sizeof(MONITORINFO{}))}
		if r, _, _ := procGetMonitorInfo.Call(hmon, uintptr(unsafe.Pointer(&mi))); r != 0 {
			if pt.X+w > mi.RcWork.Right {
				pt.X = mi.RcWork.Right - w
			}
			if pt.Y+h > mi.RcWork.Bottom {
				pt.Y = mi.RcWork.Bottom - h
			}
			if pt.X < mi.RcWork.Left {
				pt.X = mi.RcWork.Left
			}
			if pt.Y < mi.RcWork.Top {
				pt.Y = mi.RcWork.Top
			}
		}
	}
	hInst, _, _ := procGetModuleHandle.Call(0)
	className := wstr("TyporaContextMenuV413")
	hwnd, _, _ := procCreateWindowEx.Call(WS_EX_TOOLWINDOW, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(wstr(""))), WS_POPUP|WS_VISIBLE, uintptr(int64(pt.X)), uintptr(int64(pt.Y)), uintptr(w), uintptr(h), uintptr(app.hwnd), 0, hInst, 0)
	if hwnd == 0 {
		// Fallback to a normal Windows menu if the lightweight themed popup cannot
		// be created on an unusual system configuration.
		nativeItems := make([]struct {
			id    uintptr
			label string
		}, 0, len(contextEntries()))
		for i, e := range contextEntries() {
			if e.Separator {
				nativeItems = append(nativeItems, struct {
					id    uintptr
					label string
				}{0, ""})
			} else {
				nativeItems = append(nativeItems, struct {
					id    uintptr
					label string
				}{uintptr(i + 1), e.Label})
			}
		}
		if cmd := contextMenuCommand(nativeItems, x, y); cmd > 0 {
			executeContext(int(cmd - 1))
		} else {
			app.contextVisible = false
			app.contextKind = ""
			app.contextPath = ""
			app.contextTab = -1
		}
		return
	}
	app.contextHwnd = syscall.Handle(hwnd)
	app.contextHover = -1
	procSetFocus.Call(hwnd)
	procUpdateWindow.Call(hwnd)
}

func handleRightClick(x, y int32) {
	procKillTimer.Call(uintptr(app.hwnd), TIMER_TOOLTIP)
	app.tooltipVisible = false
	app.tooltipTarget = ""
	if app.onboarding || app.shortcutsVisible {
		return
	}
	app.contextVisible = false
	app.contextHover = -1
	if x >= tabStripLeft() && x < tabStripRight() && y >= TOP_H && y < TOP_H+TAB_H {
		for i := range app.docs {
			r := tabRect(i)
			if r.Right <= tabStripLeft() || r.Left >= tabStripRight() || !contains(r, x, y) {
				continue
			}
			switchTab(i)
			app.contextVisible = true
			app.contextKind = "tab"
			app.contextTab = i
			app.contextPath = app.docs[i].Path
			app.contextX, app.contextY = x, y
			showContextPopup(x, y)
			return
		}
	}
	if app.cfg.Sidebar && x < SIDEBAR_W && y > TOP_H && y < app.clientH-STATUS_H {
		idx := -1
		if y > TOP_H+70 {
			idx = app.sidebarScroll + int((y-(TOP_H+70))/32)
		}
		app.contextVisible = true
		app.contextTab = -1
		if idx >= 0 && idx < len(app.sidebarFiles) {
			app.contextKind = "sidebar"
			app.contextPath = filepath.Join(app.cfg.DefaultFolder, app.sidebarFiles[idx])
		} else {
			app.contextKind = "sidebar-root"
			app.contextPath = app.cfg.DefaultFolder
		}
		app.contextX, app.contextY = x, y
		showContextPopup(x, y)
	}
}

func openFile(path string) {
	path = filepath.Clean(path)
	for i, d := range app.docs {
		if strings.EqualFold(filepath.Clean(d.Path), path) {
			switchTab(i)
			return
		}
	}
	b, err := os.ReadFile(path)
	if err != nil {
		message(err.Error(), "Could not open file", MB_OK|MB_ICONWARNING)
		return
	}
	syncEditorToDoc()
	title := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	d := &Document{ID: randomID(), Title: title, Path: path, Content: string(b), AutoCreated: false, LastDiskMod: fileModNano(path)}
	d.BufferPath = bufferPath(d.ID)
	_ = writeBuffer(d)
	app.docs = append(app.docs, d)
	app.active = len(app.docs) - 1
	setEditorFromDoc()
	persistSessionNow()
	layout()
	invalidate()
}
func openDialog() {
	initial := app.cfg.DefaultFolder
	if d := activeDoc(); d != nil && d.Path != "" {
		initial = filepath.Dir(d.Path)
	}
	if p, err := pickMarkdownFile(app.hwnd, initial); err == nil {
		openFile(p)
	}
}
func changeDefaultFolder() {
	p, err := pickFolder(app.hwnd, app.cfg.DefaultFolder)
	if err != nil || p == "" {
		return
	}
	app.cfg.DefaultFolder = p
	_ = os.MkdirAll(p, 0755)
	_ = saveConfig(app.cfg)
	startSidebarFolderWatcher(app.cfg.DefaultFolder)
	refreshSidebar()
	invalidate()
}
func saveAsCurrent() {
	d := activeDoc()
	if d == nil {
		return
	}
	syncEditorToDoc()
	initial := app.cfg.DefaultFolder
	if d.Path != "" {
		initial = filepath.Dir(d.Path)
	}
	name := d.Title + ".md"
	p, err := saveAsDialog(app.hwnd, initial, name)
	if err != nil {
		return
	}
	if filepath.Ext(p) == "" {
		p += ".md"
	}
	old := d.Path
	oldAuto := d.AutoCreated
	if err := atomicWrite(p, []byte(d.Content), 0644); err != nil {
		message(err.Error(), "Save As failed", MB_OK|MB_ICONWARNING)
		return
	}
	d.Path = p
	d.Title = strings.TrimSuffix(filepath.Base(p), filepath.Ext(p))
	d.AutoCreated = false
	d.LastDiskMod = fileModNano(p)
	d.DiskMissing = false
	if oldAuto && old != "" && !strings.EqualFold(old, p) {
		_ = os.Remove(old)
	}
	_ = writeBuffer(d)
	persistSessionNow()
	refreshSidebar()
	updateWindowTitle()
	app.saveStatus = "Saved as " + filepath.Base(p)
	invalidate()
}

func restoreSession() {
	ensureDefaultFolder()
	s := loadSession()
	for _, sd := range s.Docs {
		var content []byte
		if sd.BufferPath != "" {
			content, _ = os.ReadFile(sd.BufferPath)
		}
		if content == nil && sd.Path != "" {
			content, _ = os.ReadFile(sd.Path)
		}
		title := sd.Title
		if title == "" && sd.Path != "" {
			title = strings.TrimSuffix(filepath.Base(sd.Path), filepath.Ext(sd.Path))
		}
		if title == "" {
			title = nextUntitled(app.cfg.DefaultFolder)
		}
		id := sd.ID
		if id == "" {
			id = randomID()
		}
		bp := sd.BufferPath
		if bp == "" {
			bp = bufferPath(id)
		}
		diskMod := fileModNano(sd.Path)
		lastMod := sd.LastDiskMod
		if lastMod == 0 {
			lastMod = diskMod
		}
		d := &Document{ID: id, Title: title, Path: sd.Path, BufferPath: bp, Content: string(content), AutoCreated: sd.AutoCreated, LastDiskMod: lastMod, DiskMissing: sd.DiskMissing || (sd.Path != "" && sd.LastDiskMod != 0 && diskMod == 0)}
		app.docs = append(app.docs, d)
	}
	if len(app.docs) == 0 {
		app.active = -1
		setEditorFromDoc()
		app.saveStatus = "Ready"
		persistSessionNow()
		layout()
		invalidate()
		return
	}
	app.active = s.Active
	if app.active < 0 || app.active >= len(app.docs) {
		app.active = 0
	}
	setEditorFromDoc()
	persistSessionNow()
}

func applySidebarOrder(files, order []string) []string {
	if len(files) == 0 {
		return nil
	}
	if len(order) == 0 {
		return append([]string(nil), files...)
	}
	byLower := make(map[string]string, len(files))
	for _, f := range files {
		byLower[strings.ToLower(f)] = f
	}
	out := make([]string, 0, len(files))
	used := make(map[string]bool, len(files))
	for _, wanted := range order {
		k := strings.ToLower(wanted)
		if f, ok := byLower[k]; ok && !used[k] {
			out = append(out, f)
			used[k] = true
		}
	}
	for _, f := range files {
		k := strings.ToLower(f)
		if !used[k] {
			out = append(out, f)
		}
	}
	return out
}

func rememberSidebarOrder() {
	app.cfg.SidebarOrder = append([]string(nil), app.sidebarFiles...)
	queueConfigPersist(app.cfg)
}

func sortSidebarAlphabetical() {
	sort.SliceStable(app.sidebarFiles, func(i, j int) bool {
		return strings.ToLower(app.sidebarFiles[i]) < strings.ToLower(app.sidebarFiles[j])
	})
	app.cfg.SidebarOrder = nil
	queueConfigPersist(app.cfg)
	app.sidebarScroll = 0
	invalidateSidebar()
}

func refreshSidebar() {
	ensureDefaultFolder()
	queueSidebarRefresh(app.cfg.DefaultFolder)
}

func renderPreview() {
	if app.view == "edit" || app.preview == 0 {
		return
	}
	d := activeDoc()
	if d == nil {
		return
	}
	// v4.8 continues to avoid EM_STREAMIN/RTF callbacks. That path could
	// hard-crash inside RichEdit and leave Split as the persisted startup mode.
	// The safe native renderer writes Unicode text and applies RichEdit formatting
	// ranges with ordinary messages instead.
	renderNativePreview(app.preview, d.Content)
}

func updateWindowTitle() {
	title := appName
	if d := activeDoc(); d != nil {
		title = d.Title + " — " + appName
	}
	setText(app.hwnd, title)
}
func setView(v string) {
	if v != "edit" && v != "split" && v != "preview" {
		return
	}
	log.Printf("View change requested: %s -> %s", app.view, v)
	app.view = v
	layout()
	if v != "edit" {
		// Render once before persisting the view choice. A bad preview renderer must
		// never be able to brick the next launch by saving a crashing startup mode.
		syncEditorToDoc()
		log.Printf("Preview render before persisting view: begin mode=%s", v)
		renderPreview()
		log.Printf("Preview render before persisting view: complete mode=%s", v)
	}
	app.cfg.View = v
	_ = saveConfig(app.cfg)
	invalidate()
	if v != "preview" {
		procSetFocus.Call(uintptr(app.editor))
	}
}
func openTutorial() {
	if app.renameActive {
		commitRename()
	}
	if app.cfg.Onboarded {
		syncEditorToDoc()
		app.tutorialRevisit = true
	} else {
		app.tutorialRevisit = false
	}
	app.tutorialStep = 0
	app.onboarding = true
	layout()
	invalidate()
}

func closeTutorial() {
	if !app.tutorialRevisit {
		return
	}
	app.onboarding = false
	app.tutorialRevisit = false
	layout()
	invalidate()
	if app.editor != 0 && app.view != "preview" {
		procSetFocus.Call(uintptr(app.editor))
	}
}

func normalizePreviewTarget(raw string) string {
	t := strings.TrimSpace(strings.Trim(raw, "<>"))
	if t == "" || strings.HasPrefix(t, "#") {
		return ""
	}
	lower := strings.ToLower(t)
	if strings.HasPrefix(lower, "https://") || strings.HasPrefix(lower, "http://") || strings.HasPrefix(lower, "mailto:") {
		return t
	}
	// Resolve an existing local relative link beside the current Markdown file.
	if d := activeDoc(); d != nil && d.Path != "" {
		candidate := t
		if !filepath.IsAbs(candidate) {
			candidate = filepath.Join(filepath.Dir(d.Path), filepath.FromSlash(candidate))
		}
		if st, err := os.Stat(candidate); err == nil && !st.IsDir() {
			return candidate
		}
	}
	// Markdown authors commonly write [label](example.com). Treat a simple bare
	// domain as HTTPS rather than asking Windows to guess a URI scheme.
	if !strings.ContainsAny(t, " \t\r\n") && strings.Contains(t, ".") && !strings.Contains(t, "://") {
		return "https://" + t
	}
	return ""
}

func openPreviewTarget(raw string) {
	target := normalizePreviewTarget(raw)
	if target == "" {
		return
	}
	// Keep local Markdown links inside the editor; everything else goes through
	// the user's normal Windows default-handler path.
	if !strings.Contains(target, "://") && !strings.HasPrefix(strings.ToLower(target), "mailto:") {
		if strings.EqualFold(filepath.Ext(target), ".md") {
			openFile(target)
			return
		}
	}
	r, _, _ := procShellExecuteW.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(wstr("open"))), uintptr(unsafe.Pointer(wstr(target))), 0, 0, SW_SHOWNORMAL)
	if r <= 32 {
		app.saveStatus = "Could not open link"
		invalidateStatus()
	}
}

func openPreviewLinkAt(start, end int32) {
	for _, l := range app.previewLinks {
		if start < int32(l.end) && end > int32(l.start) {
			openPreviewTarget(l.target)
			return
		}
	}
}

func toggleTheme() {
	if app.cfg.Theme == "light" {
		app.cfg.Theme = "dark"
	} else {
		app.cfg.Theme = "light"
	}
	_ = saveConfig(app.cfg)
	setEditorStyle()
	renderPreview()
	invalidate()
}

func wordCount(s string) int { return len(strings.Fields(s)) }

func tabStripLeft() int32 {
	if app.cfg.Sidebar {
		return SIDEBAR_W + 12
	}
	return 12
}

func tabStripRight() int32 {
	// Keep the + button pinned to the right edge of the tab row. Tabs scroll
	// underneath their own clipped viewport instead of pushing + off-screen.
	r := app.clientW - 58
	minR := tabStripLeft() + 80
	if r < minR {
		return minR
	}
	return r
}

func tabWidth() int32 {
	n := len(app.docs)
	avail := tabStripRight() - tabStripLeft()
	if avail < 108 {
		return 108
	}
	w := int32(176)
	if n > 0 && int32(n)*w > avail {
		w = avail / int32(n)
	}
	// Once tabs would become too tiny, keep a readable width and scroll the strip.
	if w < 116 {
		w = 116
	}
	if w > 176 {
		w = 176
	}
	return w
}

func maxTabScroll() int32 {
	content := int32(len(app.docs)) * tabWidth()
	avail := tabStripRight() - tabStripLeft()
	if content <= avail {
		return 0
	}
	return content - avail
}

func ensureActiveTabVisible() {
	if app.active < 0 || app.active >= len(app.docs) {
		app.tabScroll = 0
		return
	}
	maxScroll := maxTabScroll()
	if maxScroll <= 0 {
		app.tabScroll = 0
		return
	}
	if app.tabScroll < 0 {
		app.tabScroll = 0
	}
	if app.tabScroll > maxScroll {
		app.tabScroll = maxScroll
	}
	w := tabWidth()
	left := tabStripLeft()
	right := tabStripRight()
	r := RECT{
		left + int32(app.active)*w - app.tabScroll,
		TOP_H,
		left + int32(app.active+1)*w - app.tabScroll - 4,
		TOP_H + TAB_H,
	}
	if r.Left < left {
		app.tabScroll -= left - r.Left
	} else if r.Right > right {
		app.tabScroll += r.Right - right
	}
	if app.tabScroll < 0 {
		app.tabScroll = 0
	}
	if app.tabScroll > maxScroll {
		app.tabScroll = maxScroll
	}
}

func tabRect(i int) RECT {
	w := tabWidth()
	x := tabStripLeft() + int32(i)*w - app.tabScroll
	return RECT{x, TOP_H, x + w - 4, TOP_H + TAB_H}
}

func plusRect() RECT {
	return RECT{app.clientW - 48, TOP_H + 7, app.clientW - 14, TOP_H + 35}
}

func contains(r RECT, x, y int32) bool {
	return x >= r.Left && x < r.Right && y >= r.Top && y < r.Bottom
}
func max32(a, b int32) int32 {
	if a > b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func shortcutCardRect() RECT {
	w := int32(760)
	h := int32(540)
	if app.clientW < w+48 {
		w = max32(520, app.clientW-48)
	}
	if app.clientH < h+48 {
		h = max32(420, app.clientH-48)
	}
	x := (app.clientW - w) / 2
	y := (app.clientH - h) / 2
	return RECT{x, y, x + w, y + h}
}

func shortcutCloseRect() RECT {
	r := shortcutCardRect()
	return RECT{r.Right - 54, r.Top + 18, r.Right - 18, r.Top + 54}
}

func openShortcuts() {
	if app.shortcutsVisible {
		return
	}
	if app.renameActive {
		cancelRename()
	}
	if !app.onboarding {
		syncEditorToDoc()
	}
	app.shortcutsVisible = true
	app.tooltipVisible = false
	app.hover = ""
	layout()
	invalidate()
}

func closeShortcuts() {
	if !app.shortcutsVisible {
		return
	}
	app.shortcutsVisible = false
	layout()
	invalidate()
	if !app.onboarding {
		if app.view == "preview" && app.preview != 0 {
			procSetFocus.Call(uintptr(app.preview))
		} else if app.editor != 0 {
			procSetFocus.Call(uintptr(app.editor))
		}
	}
}

func paintShortcuts(hdc syscall.Handle) {
	// Keep the surrounding chrome visible so the shortcut sheet feels like part
	// of the app rather than a separate Windows dialog.
	paintNormal(hdc)
	p := colors()
	r := shortcutCardRect()
	roundFill(hdc, r, p.panel, 20)
	// A subtle border helps the sheet read against both themes.
	penColor := p.line
	fill(hdc, RECT{r.Left, r.Top, r.Right, r.Top + 1}, penColor)
	fill(hdc, RECT{r.Left, r.Bottom - 1, r.Right, r.Bottom}, penColor)
	fill(hdc, RECT{r.Left, r.Top, r.Left + 1, r.Bottom}, penColor)
	fill(hdc, RECT{r.Right - 1, r.Top, r.Right, r.Bottom}, penColor)

	drawText(hdc, "Keyboard shortcuts", RECT{r.Left + 34, r.Top + 22, r.Right - 90, r.Top + 58}, app.fontUISemibold, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, "F1 or Esc to close", RECT{r.Left + 34, r.Top + 58, r.Right - 90, r.Top + 82}, app.fontSmall, p.muted, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	cr := shortcutCloseRect()
	if app.hover == "shortcuts:close" {
		roundFill(hdc, cr, p.accentSoft, 9)
	}
	drawText(hdc, "×", cr, app.fontUISemibold, p.text, DT_CENTER|DT_VCENTER|DT_SINGLELINE)

	leftX := r.Left + 38
	rightX := r.Left + (r.Right-r.Left)/2 + 14
	top := r.Top + 106
	rowH := int32(34)

	drawText(hdc, "FILES & TABS", RECT{leftX, top, rightX - 20, top + 24}, app.fontSmall, p.muted, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	leftRows := [][2]string{
		{"Ctrl+N", "New note"},
		{"Ctrl+O", "Open file"},
		{"Ctrl+S", "Save now"},
		{"Ctrl+Shift+S", "Save As…"},
		{"Ctrl+W", "Close tab"},
		{"Ctrl+Tab", "Next tab"},
		{"Ctrl+Shift+Tab", "Previous tab"},
		{"Ctrl+Shift+T", "Reopen closed tab"},
	}
	y := top + 30
	for _, row := range leftRows {
		drawText(hdc, row[0], RECT{leftX, y, leftX + 132, y + rowH}, app.fontMono, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		drawText(hdc, row[1], RECT{leftX + 146, y, rightX - 20, y + rowH}, app.fontUI, p.muted, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		y += rowH
	}

	drawText(hdc, "EDITING & MOUSE", RECT{rightX, top, r.Right - 38, top + 24}, app.fontSmall, p.muted, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	rightRows := [][2]string{
		{"F2", "Rename current note"},
		{"Enter", "Finish renaming"},
		{"Esc", "Cancel rename / close sheet"},
		{"F1", "Keyboard shortcuts"},
		{"Middle click", "Close a tab"},
		{"Drag tab", "Rearrange tabs"},
		{"Right click", "Tab / note actions"},
		{"Mouse wheel", "Scroll long documents"},
	}
	y = top + 30
	for _, row := range rightRows {
		drawText(hdc, row[0], RECT{rightX, y, rightX + 130, y + rowH}, app.fontMono, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		drawText(hdc, row[1], RECT{rightX + 144, y, r.Right - 38, y + rowH}, app.fontUI, p.muted, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		y += rowH
	}
	drawText(hdc, "Typora v"+appVersion+"  •  native  •  local", RECT{r.Left + 38, r.Bottom - 34, r.Right - 38, r.Bottom - 12}, app.fontSmall, p.muted, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
}

func startSmoothScroll(target syscall.Handle, delta int16) {
	if target == 0 || delta == 0 {
		return
	}
	if app.scrollTarget != target {
		app.scrollTarget = target
		app.wheelRemainder = 0
		app.smoothScrollRemaining = 0
	}
	app.wheelRemainder += int(delta)
	for app.wheelRemainder >= 120 {
		app.smoothScrollRemaining -= 3
		app.wheelRemainder -= 120
	}
	for app.wheelRemainder <= -120 {
		app.smoothScrollRemaining += 3
		app.wheelRemainder += 120
	}
	if app.smoothScrollRemaining > 30 {
		app.smoothScrollRemaining = 30
	} else if app.smoothScrollRemaining < -30 {
		app.smoothScrollRemaining = -30
	}
	if app.smoothScrollRemaining != 0 {
		procSetTimer.Call(uintptr(app.hwnd), TIMER_SMOOTH_SCROLL, 12, 0)
	}
}

func richEditSubclassProc(hwnd syscall.Handle, msg uint32, wparam, lparam uintptr) uintptr {
	if hwnd == app.preview && msg == WM_PAINT {
		if paintPreviewBuffered(hwnd) {
			return 0
		}
	}
	if hwnd == app.preview && msg == WM_ERASEBKGND {
		// The buffered preview paint clears its own backbuffer. Suppressing the
		// separate erase pass prevents a background flash between scroll frames.
		return 1
	}
	if msg == WM_MOUSEWHEEL {
		startSmoothScroll(hwnd, int16((wparam>>16)&0xffff))
		return 0
	}
	old := oldEditorWndProc
	if hwnd == app.preview {
		old = oldPreviewWndProc
	}
	if old != 0 {
		r, _, _ := procCallWindowProc.Call(old, uintptr(hwnd), uintptr(msg), wparam, lparam)
		return r
	}
	return 0
}

func installRichEditSubclasses() {
	if richEditSubclassCallback == 0 {
		richEditSubclassCallback = syscall.NewCallback(richEditSubclassProc)
	}
	if app.editor != 0 && oldEditorWndProc == 0 {
		r, _, _ := procSetWindowLongPtr.Call(uintptr(app.editor), ^uintptr(3), richEditSubclassCallback) // GWLP_WNDPROC = -4
		oldEditorWndProc = r
	}
	if app.preview != 0 && oldPreviewWndProc == 0 {
		r, _, _ := procSetWindowLongPtr.Call(uintptr(app.preview), ^uintptr(3), richEditSubclassCallback)
		oldPreviewWndProc = r
	}
}

func rememberWindowPlacement() {
	if app.hwnd == 0 {
		return
	}
	wp := WINDOWPLACEMENT{Length: uint32(unsafe.Sizeof(WINDOWPLACEMENT{}))}
	r, _, _ := procGetWindowPlacement.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(&wp)))
	if r == 0 {
		return
	}
	rc := wp.RcNormalPosition
	w := rc.Right - rc.Left
	h := rc.Bottom - rc.Top
	if w < 520 || h < 360 {
		return
	}
	app.cfg.WindowX = rc.Left
	app.cfg.WindowY = rc.Top
	app.cfg.WindowW = w
	app.cfg.WindowH = h
	app.cfg.WindowMaximized = wp.ShowCmd == SW_SHOWMAXIMIZED
}

func startupWindowPlacement() (x, y, w, h int32, maximized, ok bool) {
	w, h = app.cfg.WindowW, app.cfg.WindowH
	x, y = app.cfg.WindowX, app.cfg.WindowY
	maximized = app.cfg.WindowMaximized
	if w < 520 || h < 360 {
		return 0, 0, 1360, 860, false, false
	}
	rc := RECT{x, y, x + w, y + h}
	hmon, _, _ := procMonitorFromRect.Call(uintptr(unsafe.Pointer(&rc)), 0) // MONITOR_DEFAULTTONULL
	if hmon == 0 {
		// The monitor/desktop space no longer exists (for example, a laptop was
		// unplugged from an external display). Let Windows choose a safe default.
		return 0, 0, 1360, 860, false, false
	}
	mi := MONITORINFO{CbSize: uint32(unsafe.Sizeof(MONITORINFO{}))}
	if r, _, _ := procGetMonitorInfo.Call(hmon, uintptr(unsafe.Pointer(&mi))); r != 0 {
		work := mi.RcWork
		if w > work.Right-work.Left {
			w = work.Right - work.Left
		}
		if h > work.Bottom-work.Top {
			h = work.Bottom - work.Top
		}
		if x < work.Left {
			x = work.Left
		}
		if y < work.Top {
			y = work.Top
		}
		if x+w > work.Right {
			x = work.Right - w
		}
		if y+h > work.Bottom {
			y = work.Bottom - h
		}
	}
	return x, y, w, h, maximized, true
}

func layout() {
	if app.hwnd == 0 {
		return
	}
	var rc RECT
	procGetClientRect.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(&rc)))
	app.clientW = rc.Right
	app.clientH = rc.Bottom
	ensureActiveTabVisible()
	if app.onboarding || app.shortcutsVisible {
		procShowWindow.Call(uintptr(app.editor), SW_HIDE)
		procShowWindow.Call(uintptr(app.preview), SW_HIDE)
		if app.renameEdit != 0 {
			procShowWindow.Call(uintptr(app.renameEdit), SW_HIDE)
		}
		return
	}
	if len(app.docs) == 0 || activeDoc() == nil {
		procShowWindow.Call(uintptr(app.editor), SW_HIDE)
		procShowWindow.Call(uintptr(app.preview), SW_HIDE)
		if app.renameEdit != 0 {
			procShowWindow.Call(uintptr(app.renameEdit), SW_HIDE)
		}
		return
	}
	top := int32(TOP_H + TAB_H)
	bottom := app.clientH - STATUS_H
	side := int32(0)
	if app.cfg.Sidebar {
		side = SIDEBAR_W
	}
	x := side
	w := app.clientW - side
	h := bottom - top
	if h < 1 {
		h = 1
	}
	switch app.view {
	case "split":
		half := w / 2
		procMoveWindow.Call(uintptr(app.editor), uintptr(x), uintptr(top), uintptr(half), uintptr(h), 1)
		procMoveWindow.Call(uintptr(app.preview), uintptr(x+half), uintptr(top), uintptr(w-half), uintptr(h), 1)
		procShowWindow.Call(uintptr(app.editor), SW_SHOW)
		procShowWindow.Call(uintptr(app.preview), SW_SHOW)
	case "preview":
		procMoveWindow.Call(uintptr(app.preview), uintptr(x), uintptr(top), uintptr(w), uintptr(h), 1)
		procShowWindow.Call(uintptr(app.editor), SW_HIDE)
		procShowWindow.Call(uintptr(app.preview), SW_SHOW)
	default:
		procMoveWindow.Call(uintptr(app.editor), uintptr(x), uintptr(top), uintptr(w), uintptr(h), 1)
		procShowWindow.Call(uintptr(app.preview), SW_HIDE)
		procShowWindow.Call(uintptr(app.editor), SW_SHOW)
	}
	if app.renameEdit != 0 {
		procShowWindow.Call(uintptr(app.renameEdit), SW_HIDE)
	}
}

func drawText(hdc syscall.Handle, text string, r RECT, font syscall.Handle, color uint32, flags uintptr) {
	old, _, _ := procSelectObject.Call(uintptr(hdc), uintptr(font))
	procSetBkMode.Call(uintptr(hdc), TRANSPARENT)
	procSetTextColor.Call(uintptr(hdc), uintptr(color))
	u := syscall.StringToUTF16(text)
	procDrawText.Call(uintptr(hdc), uintptr(unsafe.Pointer(&u[0])), uintptr(len(u)-1), uintptr(unsafe.Pointer(&r)), flags)
	procSelectObject.Call(uintptr(hdc), old)
}
func measureTextWidth(hdc syscall.Handle, text string, font syscall.Handle) int32 {
	if text == "" {
		return 0
	}
	old, _, _ := procSelectObject.Call(uintptr(hdc), uintptr(font))
	u := syscall.StringToUTF16(text)
	var sz SIZE
	procGetTextExtentPoint32.Call(uintptr(hdc), uintptr(unsafe.Pointer(&u[0])), uintptr(len(u)-1), uintptr(unsafe.Pointer(&sz)))
	procSelectObject.Call(uintptr(hdc), old)
	return sz.Cx
}
func fill(hdc syscall.Handle, r RECT, color uint32) {
	b, _, _ := procCreateSolidBrush.Call(uintptr(color))
	procFillRect.Call(uintptr(hdc), uintptr(unsafe.Pointer(&r)), b)
	procDeleteObject.Call(b)
}
func roundFill(hdc syscall.Handle, r RECT, color uint32, radius int32) {
	b, _, _ := procCreateSolidBrush.Call(uintptr(color))
	oldB, _, _ := procSelectObject.Call(uintptr(hdc), b)
	pen, _, _ := procCreatePen.Call(PS_SOLID, 1, uintptr(color))
	oldP, _, _ := procSelectObject.Call(uintptr(hdc), pen)
	procRoundRect.Call(uintptr(hdc), uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), uintptr(radius), uintptr(radius))
	procSelectObject.Call(uintptr(hdc), oldB)
	procSelectObject.Call(uintptr(hdc), oldP)
	procDeleteObject.Call(b)
	procDeleteObject.Call(pen)
}

func tooltipFor(key string) string {
	switch key {
	case "top:new", "plus":
		return "New note  Ctrl+N"
	case "top:open":
		return "Open file  Ctrl+O"
	case "top:folder":
		return "Change notes folder"
	case "top:saveas":
		return "Save As  Ctrl+Shift+S"
	case "top:edit":
		return "Edit only"
	case "top:split":
		return "Edit + preview"
	case "top:preview":
		return "Preview only"
	case "top:help":
		return "Tutorial"
	case "top:theme":
		return "Switch theme"
	}
	if strings.HasPrefix(key, "tabclose:") {
		return "Close tab  Ctrl+W"
	}
	return ""
}

func paintTooltip(hdc syscall.Handle) {
	if !app.tooltipVisible || app.onboarding || app.shortcutsVisible || app.tooltipTarget == "" {
		return
	}
	text := tooltipFor(app.tooltipTarget)
	if text == "" {
		return
	}
	w := int32(22 + len([]rune(text))*7)
	if w < 94 {
		w = 94
	}
	if w > 230 {
		w = 230
	}
	h := int32(28)
	x := app.mouseX + 10
	y := int32(TOP_H + 5)
	if app.mouseY >= TOP_H {
		// Tab-row tooltips sit above the tabs so they never overlap the editor child.
		y = TOP_H - h - 2
	}
	if x+w > app.clientW-8 {
		x = app.clientW - w - 8
	}
	if x < 8 {
		x = 8
	}
	if y < 4 {
		y = 4
	}
	r := RECT{x, y, x + w, y + h}
	bg := rgb(43, 49, 60)
	fg := rgb(245, 247, 250)
	if app.cfg.Theme == "light" {
		bg = rgb(42, 45, 52)
	}
	roundFill(hdc, r, bg, 7)
	drawText(hdc, text, RECT{r.Left + 9, r.Top, r.Right - 9, r.Bottom}, app.fontSmall, fg, DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
}

func dailyQuote() string {
	quotes := []string{
		"A blank page is room, not pressure.",
		"Write the next useful sentence.",
		"Small notes become clear thinking.",
		"Capture it now; organize it later.",
		"Clarity often starts as a rough draft.",
		"A good note only needs to help future you.",
		"Start messy. Keep what matters.",
		"One line is enough to begin.",
		"Ideas get lighter once they are written down.",
		"Make a place for the thought before it disappears.",
		"The shortest useful note is still useful.",
		"Write first. Refine when it earns the time.",
		"A quiet page can hold a loud idea.",
		"Progress can be a sentence.",
		"Notes are checkpoints for your brain.",
		"Give the idea somewhere to live.",
		"Keep the useful part; delete the rest.",
		"Today’s scratch note can be tomorrow’s answer.",
		"You do not need a perfect structure to start.",
		"Good systems make forgetting harmless.",
		"Write what you would want to find later.",
		"A note is a save point for a thought.",
		"Make it easy to resume.",
		"The page is ready when you are.",
	}
	if len(quotes) == 0 {
		return ""
	}
	return quotes[(time.Now().YearDay()-1)%len(quotes)]
}

func emptyStateRects() (RECT, RECT, RECT) {
	left := int32(0)
	if app.cfg.Sidebar {
		left = SIDEBAR_W
	}
	top := int32(TOP_H + TAB_H)
	bottom := app.clientH - STATUS_H
	cx := left + (app.clientW-left)/2
	cy := top + (bottom-top)/2 - 18
	icon := RECT{cx - 24, cy - 92, cx + 24, cy - 44}
	newR := RECT{cx - 142, cy + 26, cx - 8, cy + 64}
	openR := RECT{cx + 8, cy + 26, cx + 142, cy + 64}
	return icon, newR, openR
}

func paintEmptyState(hdc syscall.Handle) {
	if len(app.docs) != 0 || app.onboarding || app.shortcutsVisible {
		return
	}
	p := colors()
	iconR, newR, openR := emptyStateRects()
	cx := (iconR.Left + iconR.Right) / 2
	cy := iconR.Bottom + 28

	// A genuinely blank home state: one quiet mark, one sentence, two actions.
	// No quote carousel and no split divider competing with an empty workspace.
	if app.iconHeader != 0 {
		procDrawIconEx.Call(uintptr(hdc), uintptr(iconR.Left+8), uintptr(iconR.Top+8), uintptr(app.iconHeader), 32, 32, 0, 0, DI_NORMAL)
	} else {
		roundFill(hdc, RECT{cx - 17, iconR.Top + 7, cx + 17, iconR.Top + 41}, p.panel2, 9)
		drawText(hdc, "T", RECT{cx - 17, iconR.Top + 7, cx + 17, iconR.Top + 41}, app.fontUISemibold, p.text, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}
	drawText(hdc, "No notes open", RECT{cx - 220, cy - 6, cx + 220, cy + 24}, app.fontUISemibold, p.text, DT_CENTER|DT_VCENTER|DT_SINGLELINE)

	for _, b := range []struct {
		r     RECT
		key   string
		label string
	}{
		{newR, "empty:new", "+  New note"},
		{openR, "empty:open", "Open file"},
	} {
		bg := p.panel2
		if app.hover == b.key {
			bg = p.accentSoft
		}
		roundFill(hdc, b.r, bg, 9)
		drawText(hdc, b.label, b.r, app.fontUI, p.text, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}
	drawText(hdc, "Ctrl+N                                      Ctrl+O", RECT{newR.Left, newR.Bottom + 8, openR.Right, openR.Bottom + 30}, app.fontSmall, p.muted, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
}

func paintNormal(hdc syscall.Handle) {
	p := colors()
	fill(hdc, RECT{0, 0, app.clientW, app.clientH}, p.bg)
	fill(hdc, RECT{0, 0, app.clientW, TOP_H}, p.panel)
	fill(hdc, RECT{0, TOP_H, app.clientW, TOP_H + TAB_H}, p.panel2)
	fill(hdc, RECT{0, app.clientH - STATUS_H, app.clientW, app.clientH}, p.panel)
	if app.iconHeader != 0 {
		procDrawIconEx.Call(uintptr(hdc), 22, 15, uintptr(app.iconHeader), 24, 24, 0, 0, DI_NORMAL)
	} else {
		drawText(hdc, "T", RECT{18, 11, 48, 43}, app.fontUISemibold, p.text, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}
	drawText(hdc, "Typora", RECT{58, 10, 145, 36}, app.fontUISemibold, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	// Leave enough room for two-digit minor versions such as v4.10/v4.11.
	drawText(hdc, "native • local • v"+strings.TrimSuffix(appVersion, ".0"), RECT{58, 30, 205, 48}, app.fontSmall, p.muted, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	buttons := []struct {
		name, label string
		r           RECT
	}{{"new", "New", RECT{210, 11, 262, 43}}, {"open", "Open", RECT{268, 11, 326, 43}}, {"folder", "Folder", RECT{332, 11, 400, 43}}, {"saveas", "Save As", RECT{406, 11, 484, 43}}, {"edit", "Edit", RECT{app.clientW - 324, 11, app.clientW - 270, 43}}, {"split", "Split", RECT{app.clientW - 266, 11, app.clientW - 208, 43}}, {"preview", "Preview", RECT{app.clientW - 204, 11, app.clientW - 130, 43}}, {"help", "?", RECT{app.clientW - 118, 11, app.clientW - 82, 43}}, {"theme", "◐", RECT{app.clientW - 70, 11, app.clientW - 30, 43}}}
	for _, b := range buttons {
		sel := (b.name == "edit" && app.view == "edit") || (b.name == "split" && app.view == "split") || (b.name == "preview" && app.view == "preview")
		hovered := app.hover == "top:"+b.name
		if sel {
			roundFill(hdc, b.r, p.accentSoft, 10)
		} else if hovered {
			roundFill(hdc, b.r, p.panel2, 10)
		}
		drawText(hdc, b.label, b.r, app.fontUI, func() uint32 {
			if sel || hovered {
				return p.text
			}
			return p.muted
		}(), DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}
	if app.cfg.Sidebar {
		fill(hdc, RECT{0, TOP_H, SIDEBAR_W, app.clientH - STATUS_H}, p.panel)
		drawText(hdc, "NOTES", RECT{18, TOP_H + 13, SIDEBAR_W - 18, TOP_H + 34}, app.fontSmall, p.muted, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		folder := filepath.Base(app.cfg.DefaultFolder)
		drawText(hdc, folder, RECT{18, TOP_H + 34, SIDEBAR_W - 18, TOP_H + 59}, app.fontUI, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
		y := int32(TOP_H + 70)
		start := app.sidebarScroll
		for i := start; i < len(app.sidebarFiles) && y < app.clientH-STATUS_H-24; i++ {
			name := app.sidebarFiles[i]
			rr := RECT{12, y, SIDEBAR_W - 10, y + 30}
			if app.sidebarDragging && i == app.sidebarDrag {
				// Leave a visible destination slot while the dragged note floats.
				roundFill(hdc, rr, p.line, 8)
				roundFill(hdc, RECT{rr.Left + 1, rr.Top + 1, rr.Right - 1, rr.Bottom - 1}, p.panel, 7)
				y += 32
				continue
			}
			active := false
			if d := activeDoc(); d != nil && strings.EqualFold(filepath.Base(d.Path), name) {
				active = true
				roundFill(hdc, rr, p.accentSoft, 8)
			} else if app.hover == fmt.Sprintf("sidebar:%d", i) {
				// Sidebar rows need a slightly stronger hover than the surrounding panel.
				hoverColor := rgb(48, 56, 70)
				if app.cfg.Theme == "light" {
					hoverColor = rgb(233, 237, 246)
				}
				roundFill(hdc, rr, hoverColor, 8)
			}
			_ = active
			drawText(hdc, name, RECT{20, y, SIDEBAR_W - 16, y + 30}, app.fontUI, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
			y += 32
		}
		if app.sidebarDragging && app.sidebarDrag >= 0 && app.sidebarDrag < len(app.sidebarFiles) {
			gy := app.sidebarDragVisualY - 15
			if gy < TOP_H+70 {
				gy = TOP_H + 70
			}
			if gy+30 > app.clientH-STATUS_H-4 {
				gy = app.clientH - STATUS_H - 34
			}
			gr := RECT{12, gy, SIDEBAR_W - 10, gy + 30}
			shadow := rgb(8, 10, 14)
			if app.cfg.Theme == "light" {
				shadow = rgb(205, 210, 222)
			}
			roundFill(hdc, RECT{gr.Left + 2, gr.Top + 3, gr.Right + 2, gr.Bottom + 3}, shadow, 8)
			roundFill(hdc, gr, p.accentSoft, 8)
			drawText(hdc, app.sidebarFiles[app.sidebarDrag], RECT{gr.Left + 10, gr.Top, gr.Right - 10, gr.Bottom}, app.fontUI, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
		}
	}
	// Tabs get their own clipped viewport. This keeps a large session from ever
	// painting over (or pushing away) the permanently pinned + button.
	savedDC, _, _ := procSaveDC.Call(uintptr(hdc))
	if savedDC != 0 {
		procIntersectClipRect.Call(uintptr(hdc), uintptr(tabStripLeft()), uintptr(TOP_H), uintptr(tabStripRight()), uintptr(TOP_H+TAB_H))
	}
	for i, d := range app.docs {
		r := tabRect(i)
		if r.Right <= tabStripLeft() || r.Left >= tabStripRight() {
			continue
		}
		if app.dragging && i == app.dragTab {
			// Leave a quiet destination slot while the active tab floats under the cursor.
			roundFill(hdc, RECT{r.Left + 3, r.Top + 8, r.Right - 3, r.Bottom - 6}, p.line, 9)
			continue
		}
		tabHovered := app.hover == fmt.Sprintf("tab:%d", i) || app.hover == fmt.Sprintf("tabclose:%d", i)
		if i == app.active {
			roundFill(hdc, RECT{r.Left, r.Top + 5, r.Right, r.Bottom - 4}, p.panel, 9)
			fill(hdc, RECT{r.Left + 12, r.Bottom - 4, r.Right - 12, r.Bottom - 2}, p.accent)
		} else if tabHovered {
			// Use the accent tint rather than the tab-strip background so hovering the
			// tab body is as obvious as hovering its close button.
			roundFill(hdc, RECT{r.Left, r.Top + 5, r.Right, r.Bottom - 4}, p.accentSoft, 9)
			fill(hdc, RECT{r.Left + 14, r.Bottom - 4, r.Right - 14, r.Bottom - 2}, p.accent)
		}
		drawText(hdc, d.Title, RECT{r.Left + 12, r.Top, r.Right - 28, r.Bottom}, app.fontUI, func() uint32 {
			if i == app.active || tabHovered {
				return p.text
			}
			return p.muted
		}(), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
		closeR := RECT{r.Right - 26, r.Top + 6, r.Right - 6, r.Bottom - 6}
		if app.hover == fmt.Sprintf("tabclose:%d", i) {
			roundFill(hdc, closeR, p.line, 7)
		}
		drawText(hdc, "×", RECT{r.Right - 26, r.Top, r.Right - 6, r.Bottom}, app.fontUI, func() uint32 {
			if app.hover == fmt.Sprintf("tabclose:%d", i) {
				return p.text
			}
			return p.muted
		}(), DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}
	if app.dragging && app.dragTab >= 0 && app.dragTab < len(app.docs) {
		w := tabWidth()
		cx := app.dragVisualX
		if cx == 0 {
			cx = app.dragStartX
		}
		fr := RECT{cx - w/2, TOP_H + 1, cx + w/2, TOP_H + TAB_H - 1}
		if fr.Left < tabStripLeft()+2 {
			fr.Right += tabStripLeft() + 2 - fr.Left
			fr.Left = tabStripLeft() + 2
		}
		if fr.Right > tabStripRight()-2 {
			fr.Left -= fr.Right - (tabStripRight() - 2)
			fr.Right = tabStripRight() - 2
		}
		shadowColor := rgb(8, 10, 14)
		if app.cfg.Theme == "light" {
			shadowColor = rgb(205, 210, 222)
		}
		roundFill(hdc, RECT{fr.Left + 3, fr.Top + 4, fr.Right + 3, fr.Bottom + 4}, shadowColor, 10)
		roundFill(hdc, fr, p.accentSoft, 10)
		fill(hdc, RECT{fr.Left + 12, fr.Bottom - 3, fr.Right - 12, fr.Bottom - 1}, p.accent)
		drawText(hdc, app.docs[app.dragTab].Title, RECT{fr.Left + 14, fr.Top, fr.Right - 14, fr.Bottom}, app.fontUI, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
	}
	if savedDC != 0 {
		procRestoreDC.Call(uintptr(hdc), savedDC)
	}
	pr := plusRect()
	if app.hover == "plus" {
		roundFill(hdc, pr, p.accentSoft, 8)
	} else {
		roundFill(hdc, pr, p.panel, 8)
	}
	drawText(hdc, "+", pr, app.fontUISemibold, p.text, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	if app.view == "split" && len(app.docs) > 0 {
		x := int32(SIDEBAR_W) + (app.clientW-SIDEBAR_W)/2
		fill(hdc, RECT{x - 1, TOP_H + TAB_H, x, app.clientH - STATUS_H}, p.line)
	}
	paintEmptyState(hdc)
	statusColor := p.statusGood
	if strings.Contains(strings.ToLower(app.saveStatus), "failed") || strings.Contains(strings.ToLower(app.saveStatus), "external") {
		statusColor = p.danger
	}
	drawText(hdc, app.saveStatus, RECT{16, app.clientH - STATUS_H, 340, app.clientH}, app.fontSmall, statusColor, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	if d := activeDoc(); d != nil {
		right := fmt.Sprintf("%d words   %d characters   %s", wordCount(d.Content), len([]rune(d.Content)), d.Path)
		drawText(hdc, right, RECT{360, app.clientH - STATUS_H, app.clientW - 18, app.clientH}, app.fontSmall, p.muted, DT_RIGHT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
	}
	paintTooltip(hdc)
}

func paintOnboarding(hdc syscall.Handle) {
	p := colors()
	fill(hdc, RECT{0, 0, app.clientW, app.clientH}, p.bg)
	cw := int32(760)
	ch := int32(480)
	x := (app.clientW - cw) / 2
	y := (app.clientH - ch) / 2
	card := RECT{x, y, x + cw, y + ch}
	roundFill(hdc, card, p.panel, 22)
	drawText(hdc, "T", RECT{x + 42, y + 34, x + 86, y + 78}, app.fontUISemibold, p.text, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, "Welcome to Typora", RECT{x + 104, y + 34, x + 650, y + 76}, app.fontUISemibold, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	if app.tutorialStep == 0 {
		drawText(hdc, "A fast native Markdown notebook that behaves more like modern Notepad than a traditional editor.", RECT{x + 52, y + 116, x + 708, y + 190}, app.fontUI, p.muted, DT_LEFT|DT_WORDBREAK)
		drawText(hdc, "• Tabs restore after restart\n• Notes save continuously\n• Unsaved work has a separate recovery buffer\n• No browser, account, cloud, or subscription", RECT{x + 52, y + 204, x + 700, y + 330}, app.fontUI, p.text, DT_LEFT|DT_WORDBREAK)
		button(hdc, RECT{x + 548, y + 394, x + 698, y + 438}, "Next", true, "tutorial:next")
	} else if app.tutorialStep == 1 {
		drawText(hdc, "Choose your notes folder", RECT{x + 52, y + 112, x + 700, y + 150}, app.fontUISemibold, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		drawText(hdc, "Every new tab gets a real .md file here automatically. You can change this later.", RECT{x + 52, y + 158, x + 700, y + 214}, app.fontUI, p.muted, DT_LEFT|DT_WORDBREAK)
		roundFill(hdc, RECT{x + 52, y + 232, x + 708, y + 286}, p.panel2, 10)
		drawText(hdc, app.cfg.DefaultFolder, RECT{x + 70, y + 232, x + 686, y + 286}, app.fontMono, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
		button(hdc, RECT{x + 52, y + 312, x + 230, y + 356}, "Choose folder", false, "tutorial:folder")
		button(hdc, RECT{x + 548, y + 394, x + 698, y + 438}, "Next", true, "tutorial:next")
		button(hdc, RECT{x + 384, y + 394, x + 534, y + 438}, "Back", false, "tutorial:back0")
	} else {
		drawText(hdc, "Saving is intentionally boring", RECT{x + 52, y + 112, x + 700, y + 150}, app.fontUISemibold, p.text, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		drawText(hdc, "Type normally and Typora saves after a short idle moment. Ctrl+S forces an immediate flush. Ctrl+Shift+S opens the normal Windows Save As dialog.\n\nNew tabs begin in rename mode with Untitled 01 selected. Close the app whenever you want; your tabs and latest buffers return next launch.\n\nOpen this guide again with the small ? in the top-right. Press F1 anytime for the complete keyboard shortcut list.", RECT{x + 52, y + 164, x + 700, y + 350}, app.fontUI, p.text, DT_LEFT|DT_WORDBREAK)
		finishLabel := "Start writing"
		if app.tutorialRevisit {
			finishLabel = "Back to editor"
		}
		button(hdc, RECT{x + 518, y + 394, x + 698, y + 438}, finishLabel, true, "tutorial:finish")
		button(hdc, RECT{x + 352, y + 394, x + 504, y + 438}, "Back", false, "tutorial:back1")
	}
}
func button(hdc syscall.Handle, r RECT, label string, primary bool, key string) {
	p := colors()
	hovered := app.hover == key
	c := p.panel2
	if hovered {
		c = p.accentSoft
	}
	if primary {
		c = p.accent
		if hovered {
			// A soft outer halo makes the hover obvious without changing layout.
			roundFill(hdc, r, p.accentSoft, 10)
			r = RECT{r.Left + 2, r.Top + 2, r.Right - 2, r.Bottom - 2}
		}
	}
	roundFill(hdc, r, c, 10)
	drawText(hdc, label, r, app.fontUI, func() uint32 {
		if primary {
			return rgb(255, 255, 255)
		}
		return p.text
	}(), DT_CENTER|DT_VCENTER|DT_SINGLELINE)
}

func paint() {
	var ps PAINTSTRUCT
	hdc, _, _ := procBeginPaint.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(&ps)))
	if hdc == 0 {
		return
	}
	defer procEndPaint.Call(uintptr(app.hwnd), uintptr(unsafe.Pointer(&ps)))
	if app.clientW <= 0 || app.clientH <= 0 {
		return
	}

	// Double-buffer the custom chrome. RichEdit children paint themselves; the
	// WS_CLIPCHILDREN clip on the destination HDC keeps the final blit out of them.
	mem, _, _ := procCreateCompatibleDC.Call(hdc)
	if mem == 0 {
		if app.shortcutsVisible {
			paintShortcuts(syscall.Handle(hdc))
		} else if app.onboarding {
			paintOnboarding(syscall.Handle(hdc))
		} else {
			paintNormal(syscall.Handle(hdc))
		}
		return
	}
	bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(app.clientW), uintptr(app.clientH))
	if bmp == 0 {
		procDeleteDC.Call(mem)
		if app.shortcutsVisible {
			paintShortcuts(syscall.Handle(hdc))
		} else if app.onboarding {
			paintOnboarding(syscall.Handle(hdc))
		} else {
			paintNormal(syscall.Handle(hdc))
		}
		return
	}
	old, _, _ := procSelectObject.Call(mem, bmp)
	if app.shortcutsVisible {
		paintShortcuts(syscall.Handle(mem))
	} else if app.onboarding {
		paintOnboarding(syscall.Handle(mem))
	} else {
		paintNormal(syscall.Handle(mem))
	}
	procBitBlt.Call(hdc, 0, 0, uintptr(app.clientW), uintptr(app.clientH), mem, 0, 0, SRCCOPY)
	procSelectObject.Call(mem, old)
	procDeleteObject.Call(bmp)
	procDeleteDC.Call(mem)
}

func topButtonHit(x, y int32) string {
	if y < 11 || y >= 43 {
		return ""
	}
	buttons := []struct {
		name string
		r    RECT
	}{{"new", RECT{210, 11, 262, 43}}, {"open", RECT{268, 11, 326, 43}}, {"folder", RECT{332, 11, 400, 43}}, {"saveas", RECT{406, 11, 484, 43}}, {"edit", RECT{app.clientW - 324, 11, app.clientW - 270, 43}}, {"split", RECT{app.clientW - 266, 11, app.clientW - 208, 43}}, {"preview", RECT{app.clientW - 204, 11, app.clientW - 130, 43}}, {"help", RECT{app.clientW - 118, 11, app.clientW - 82, 43}}, {"theme", RECT{app.clientW - 70, 11, app.clientW - 30, 43}}}
	for _, b := range buttons {
		if contains(b.r, x, y) {
			return b.name
		}
	}
	return ""
}

func hoverTargetAt(x, y int32) string {
	if app.shortcutsVisible {
		if contains(shortcutCloseRect(), x, y) {
			return "shortcuts:close"
		}
		return ""
	}
	if app.onboarding {
		cw := int32(760)
		ch := int32(480)
		cx := (app.clientW - cw) / 2
		cy := (app.clientH - ch) / 2
		if app.tutorialStep == 0 && contains(RECT{cx + 548, cy + 394, cx + 698, cy + 438}, x, y) {
			return "tutorial:next"
		}
		if app.tutorialStep == 1 {
			if contains(RECT{cx + 52, cy + 312, cx + 230, cy + 356}, x, y) {
				return "tutorial:folder"
			}
			if contains(RECT{cx + 384, cy + 394, cx + 534, cy + 438}, x, y) {
				return "tutorial:back0"
			}
			if contains(RECT{cx + 548, cy + 394, cx + 698, cy + 438}, x, y) {
				return "tutorial:next"
			}
		}
		if app.tutorialStep == 2 {
			if contains(RECT{cx + 352, cy + 394, cx + 504, cy + 438}, x, y) {
				return "tutorial:back1"
			}
			if contains(RECT{cx + 518, cy + 394, cx + 698, cy + 438}, x, y) {
				return "tutorial:finish"
			}
		}
		return ""
	}
	if len(app.docs) == 0 {
		_, newR, openR := emptyStateRects()
		if contains(newR, x, y) {
			return "empty:new"
		}
		if contains(openR, x, y) {
			return "empty:open"
		}
	}
	if name := topButtonHit(x, y); name != "" {
		return "top:" + name
	}
	if contains(plusRect(), x, y) {
		return "plus"
	}
	if x >= tabStripLeft() && x < tabStripRight() && y >= TOP_H && y < TOP_H+TAB_H {
		for i := range app.docs {
			r := tabRect(i)
			if r.Right <= tabStripLeft() || r.Left >= tabStripRight() {
				continue
			}
			if contains(RECT{r.Right - 30, r.Top, r.Right, r.Bottom}, x, y) {
				return fmt.Sprintf("tabclose:%d", i)
			}
			if contains(r, x, y) {
				return fmt.Sprintf("tab:%d", i)
			}
		}
	}
	if app.cfg.Sidebar && x < SIDEBAR_W && y > TOP_H+70 && y < app.clientH-STATUS_H {
		idx := app.sidebarScroll + int((y-(TOP_H+70))/32)
		if idx >= 0 && idx < len(app.sidebarFiles) {
			return fmt.Sprintf("sidebar:%d", idx)
		}
	}
	return ""
}

func handleMouseMove(x, y int32) {
	app.mouseX, app.mouseY = x, y
	if !app.mouseTracking {
		tme := TRACKMOUSEEVENT{CbSize: uint32(unsafe.Sizeof(TRACKMOUSEEVENT{})), DwFlags: TME_LEAVE, HwndTrack: app.hwnd}
		procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		app.mouseTracking = true
	}
	next := hoverTargetAt(x, y)
	if next != app.hover {
		procKillTimer.Call(uintptr(app.hwnd), TIMER_TOOLTIP)
		app.tooltipVisible = false
		app.tooltipTarget = ""
		app.hover = next
		if tooltipFor(next) != "" {
			procSetTimer.Call(uintptr(app.hwnd), TIMER_TOOLTIP, 450, 0)
		}
		// Repaint only when entering/leaving a target, not on every mouse pixel.
		invalidate()
	}
}

func clearHover() {
	app.mouseTracking = false
	procKillTimer.Call(uintptr(app.hwnd), TIMER_TOOLTIP)
	if app.hover != "" || app.tooltipVisible {
		app.hover = ""
		app.tooltipVisible = false
		app.tooltipTarget = ""
		invalidate()
	}
}

func handleClick(x, y int32) {
	procKillTimer.Call(uintptr(app.hwnd), TIMER_TOOLTIP)
	app.tooltipVisible = false
	app.tooltipTarget = ""
	if app.shortcutsVisible {
		if contains(shortcutCloseRect(), x, y) || !contains(shortcutCardRect(), x, y) {
			closeShortcuts()
		}
		return
	}
	if app.onboarding {
		cw := int32(760)
		ch := int32(480)
		cx := (app.clientW - cw) / 2
		cy := (app.clientH - ch) / 2
		if app.tutorialStep == 0 && contains(RECT{cx + 548, cy + 394, cx + 698, cy + 438}, x, y) {
			app.tutorialStep = 1
			invalidate()
			return
		}
		if app.tutorialStep == 1 {
			if contains(RECT{cx + 52, cy + 312, cx + 230, cy + 356}, x, y) {
				changeDefaultFolder()
				return
			}
			if contains(RECT{cx + 384, cy + 394, cx + 534, cy + 438}, x, y) {
				app.tutorialStep = 0
				invalidate()
				return
			}
			if contains(RECT{cx + 548, cy + 394, cx + 698, cy + 438}, x, y) {
				app.tutorialStep = 2
				invalidate()
				return
			}
		}
		if app.tutorialStep == 2 {
			if contains(RECT{cx + 352, cy + 394, cx + 504, cy + 438}, x, y) {
				app.tutorialStep = 1
				invalidate()
				return
			}
			if contains(RECT{cx + 518, cy + 394, cx + 698, cy + 438}, x, y) {
				if app.tutorialRevisit {
					closeTutorial()
					return
				}
				app.cfg.Onboarded = true
				_ = saveConfig(app.cfg)
				app.onboarding = false
				refreshSidebar()
				layout()
				newDocument()
				invalidate()
				return
			}
		}
		return
	}
	if len(app.docs) == 0 {
		_, newR, openR := emptyStateRects()
		if contains(newR, x, y) {
			newDocument()
			return
		}
		if contains(openR, x, y) {
			openDialog()
			return
		}
	}
	if name := topButtonHit(x, y); name != "" {
		switch name {
		case "new":
			newDocument()
		case "open":
			openDialog()
		case "folder":
			changeDefaultFolder()
		case "saveas":
			saveAsCurrent()
		case "edit":
			setView("edit")
		case "split":
			setView("split")
		case "preview":
			setView("preview")
		case "help":
			openTutorial()
		case "theme":
			toggleTheme()
		}
		return
	}
	if contains(plusRect(), x, y) {
		newDocument()
		return
	}
	if x >= tabStripLeft() && x < tabStripRight() && y >= TOP_H && y < TOP_H+TAB_H {
		for i := range app.docs {
			r := tabRect(i)
			if r.Right <= tabStripLeft() || r.Left >= tabStripRight() {
				continue
			}
			if contains(RECT{r.Right - 30, r.Top, r.Right, r.Bottom}, x, y) {
				closeTab(i)
				return
			}
			if contains(r, x, y) {
				switchTab(i)
				return
			}
		}
	}
	if app.cfg.Sidebar && x < SIDEBAR_W && y > TOP_H+70 && y < app.clientH-STATUS_H {
		idx := app.sidebarScroll + int((y-(TOP_H+70))/32)
		if idx >= 0 && idx < len(app.sidebarFiles) {
			openFile(filepath.Join(app.cfg.DefaultFolder, app.sidebarFiles[idx]))
		}
	}
}

func startTabDrag(x, y int32) bool {
	if app.onboarding || y < TOP_H || y >= TOP_H+TAB_H || x < tabStripLeft() || x >= tabStripRight() {
		return false
	}
	for i := range app.docs {
		r := tabRect(i)
		if r.Right <= tabStripLeft() || r.Left >= tabStripRight() || !contains(r, x, y) {
			continue
		}
		// The close glyph remains an ordinary button, never a drag handle.
		if contains(RECT{r.Right - 30, r.Top, r.Right, r.Bottom}, x, y) {
			return false
		}
		switchTab(i)
		app.dragTab = i
		app.dragStartX, app.dragStartY = x, y
		app.dragVisualX = x
		app.dragging = false
		app.dragMoved = false
		procSetCapture.Call(uintptr(app.hwnd))
		return true
	}
	return false
}

func moveTab(from, to int) {
	if from < 0 || from >= len(app.docs) || to < 0 || to >= len(app.docs) || from == to {
		return
	}
	d := app.docs[from]
	if from < to {
		copy(app.docs[from:to], app.docs[from+1:to+1])
	} else {
		copy(app.docs[to+1:from+1], app.docs[to:from])
	}
	app.docs[to] = d
	app.active = to
	app.dragTab = to
	app.dragMoved = true
	ensureActiveTabVisible()
	invalidateRegion(RECT{tabStripLeft(), TOP_H, app.clientW, TOP_H + TAB_H})
}

func handleTabDrag(x, y int32) {
	if app.dragTab < 0 || len(app.docs) < 2 {
		return
	}
	app.dragVisualX = x
	if app.dragging {
		invalidateRegion(RECT{tabStripLeft(), TOP_H, tabStripRight(), TOP_H + TAB_H})
	}
	if !app.dragging {
		dx := x - app.dragStartX
		dy := y - app.dragStartY
		if dx < 0 {
			dx = -dx
		}
		if dy < 0 {
			dy = -dy
		}
		if dx < 5 && dy < 5 {
			return
		}
		app.dragging = true
		invalidateRegion(RECT{tabStripLeft(), TOP_H, tabStripRight(), TOP_H + TAB_H})
	}
	left, right := tabStripLeft(), tabStripRight()
	if x < left+24 && app.tabScroll > 0 {
		app.tabScroll -= 18
		if app.tabScroll < 0 {
			app.tabScroll = 0
		}
	} else if x > right-24 && app.tabScroll < maxTabScroll() {
		app.tabScroll += 18
		if app.tabScroll > maxTabScroll() {
			app.tabScroll = maxTabScroll()
		}
	}
	w := tabWidth()
	virtualX := x + app.tabScroll - left
	to := int(virtualX / w)
	if x <= left {
		to = 0
	}
	if x >= right {
		to = len(app.docs) - 1
	}
	if to < 0 {
		to = 0
	}
	if to >= len(app.docs) {
		to = len(app.docs) - 1
	}
	moveTab(app.dragTab, to)
}

func finishTabDrag() {
	if app.dragTab < 0 {
		return
	}
	moved := app.dragMoved
	procReleaseCapture.Call()
	app.dragTab = -1
	app.dragVisualX = 0
	app.dragging = false
	app.dragMoved = false
	invalidateRegion(RECT{tabStripLeft(), TOP_H, tabStripRight(), TOP_H + TAB_H})
	if moved {
		persistSessionAsync()
	}
}

func sidebarItemRect(i int) RECT {
	y := int32(TOP_H+70) + int32(i-app.sidebarScroll)*32
	return RECT{12, y, SIDEBAR_W - 10, y + 30}
}

func startSidebarDrag(x, y int32) bool {
	if app.onboarding || app.shortcutsVisible || !app.cfg.Sidebar || x >= SIDEBAR_W || y <= TOP_H+70 || y >= app.clientH-STATUS_H {
		return false
	}
	idx := app.sidebarScroll + int((y-(TOP_H+70))/32)
	if idx < 0 || idx >= len(app.sidebarFiles) {
		return false
	}
	app.sidebarDrag = idx
	app.sidebarDragStartY = y
	app.sidebarDragVisualY = y
	app.sidebarDragging = false
	app.sidebarDragMoved = false
	procSetCapture.Call(uintptr(app.hwnd))
	return true
}

func moveSidebarItem(from, to int) {
	if from < 0 || from >= len(app.sidebarFiles) || to < 0 || to >= len(app.sidebarFiles) || from == to {
		return
	}
	name := app.sidebarFiles[from]
	if from < to {
		copy(app.sidebarFiles[from:to], app.sidebarFiles[from+1:to+1])
	} else {
		copy(app.sidebarFiles[to+1:from+1], app.sidebarFiles[to:from])
	}
	app.sidebarFiles[to] = name
	app.sidebarDrag = to
	app.sidebarDragMoved = true
	invalidateSidebar()
}

func handleSidebarDrag(x, y int32) {
	if app.sidebarDrag < 0 || len(app.sidebarFiles) == 0 {
		return
	}
	app.sidebarDragVisualY = y
	if !app.sidebarDragging {
		dy := y - app.sidebarDragStartY
		if dy < 0 {
			dy = -dy
		}
		if dy < 5 {
			return
		}
		app.sidebarDragging = true
		invalidateSidebar()
	}
	if y < TOP_H+86 && app.sidebarScroll > 0 {
		app.sidebarScroll--
	} else if y > app.clientH-STATUS_H-34 {
		visible := int((app.clientH - STATUS_H - (TOP_H + 70)) / 32)
		maxScroll := max(0, len(app.sidebarFiles)-visible)
		if app.sidebarScroll < maxScroll {
			app.sidebarScroll++
		}
	}
	to := app.sidebarScroll + int((y-(TOP_H+70))/32)
	if to < 0 {
		to = 0
	}
	if to >= len(app.sidebarFiles) {
		to = len(app.sidebarFiles) - 1
	}
	moveSidebarItem(app.sidebarDrag, to)
}

func finishSidebarDrag() {
	if app.sidebarDrag < 0 {
		return
	}
	idx := app.sidebarDrag
	moved := app.sidebarDragMoved
	name := ""
	if idx >= 0 && idx < len(app.sidebarFiles) {
		name = app.sidebarFiles[idx]
	}
	procReleaseCapture.Call()
	app.sidebarDrag = -1
	app.sidebarDragVisualY = 0
	app.sidebarDragging = false
	app.sidebarDragMoved = false
	invalidateSidebar()
	// Finish the visual drop immediately, before even queueing persistence. The
	// tab strip already behaves this way; keeping the sidebar on the same path
	// makes note reordering feel equally direct instead of "settling" a moment
	// after mouse-up.
	procUpdateWindow.Call(uintptr(app.hwnd))
	if moved {
		rememberSidebarOrder()
		return
	}
	if name != "" {
		openFile(filepath.Join(app.cfg.DefaultFolder, name))
	}
}

func handleMiddleClick(x, y int32) {
	if app.onboarding || y < TOP_H || y >= TOP_H+TAB_H || x < tabStripLeft() || x >= tabStripRight() {
		return
	}
	for i := range app.docs {
		r := tabRect(i)
		if r.Right <= tabStripLeft() || r.Left >= tabStripRight() {
			continue
		}
		if contains(r, x, y) {
			closeTab(i)
			return
		}
	}
}

func handleWheel(delta int16, x, y int32) {
	// When many tabs overflow, the wheel over the tab row pans the strip while
	// the + button remains pinned. Ctrl+Tab still works regardless of visibility.
	if y >= TOP_H && y < TOP_H+TAB_H && x >= tabStripLeft() && x < app.clientW {
		step := int32(88)
		if delta < 0 {
			app.tabScroll += step
		} else {
			app.tabScroll -= step
		}
		if app.tabScroll < 0 {
			app.tabScroll = 0
		}
		if m := maxTabScroll(); app.tabScroll > m {
			app.tabScroll = m
		}
		invalidateRegion(RECT{tabStripLeft(), TOP_H, app.clientW, TOP_H + TAB_H})
		return
	}
	if !app.cfg.Sidebar || x >= SIDEBAR_W {
		return
	}
	if delta < 0 {
		app.sidebarScroll += 3
	} else {
		app.sidebarScroll -= 3
	}
	maxScroll := max(0, len(app.sidebarFiles)-1)
	if app.sidebarScroll < 0 {
		app.sidebarScroll = 0
	}
	if app.sidebarScroll > maxScroll {
		app.sidebarScroll = maxScroll
	}
	invalidateSidebar()
}

func handleTimer(id uintptr) {
	switch id {
	case TIMER_AUTOSAVE:
		procKillTimer.Call(uintptr(app.hwnd), TIMER_AUTOSAVE)
		syncEditorToDoc()
		if d := activeDoc(); d != nil {
			if d.DiskMissing {
				app.saveStatus = "Deleted externally • Ctrl+S to restore or Ctrl+Shift+S for Save As"
				invalidateStatus()
			} else {
				queueDiskSave(d, false, false)
			}
		}
	case TIMER_PREVIEW:
		procKillTimer.Call(uintptr(app.hwnd), TIMER_PREVIEW)
		syncEditorToDoc()
		renderPreview()
	case TIMER_RECOVERY:
		procKillTimer.Call(uintptr(app.hwnd), TIMER_RECOVERY)
		syncEditorToDoc()
		if d := activeDoc(); d != nil {
			queueRecovery(d)
		}
	case TIMER_TOOLTIP:
		procKillTimer.Call(uintptr(app.hwnd), TIMER_TOOLTIP)
		if app.hover != "" && tooltipFor(app.hover) != "" {
			app.tooltipVisible = true
			app.tooltipTarget = app.hover
			invalidate()
		}
	case TIMER_SMOOTH_SCROLL:
		if app.scrollTarget == 0 || app.smoothScrollRemaining == 0 {
			procKillTimer.Call(uintptr(app.hwnd), TIMER_SMOOTH_SCROLL)
			return
		}
		step := 1
		if app.smoothScrollRemaining < 0 {
			step = -1
		}
		send(app.scrollTarget, EM_LINESCROLL, 0, uintptr(int64(step)))
		// RichEdit invalidates the scrolled area itself. Forcing another full
		// preview invalidation here caused a second paint pass and visible flicker.
		app.smoothScrollRemaining -= step
		if app.smoothScrollRemaining == 0 {
			procKillTimer.Call(uintptr(app.hwnd), TIMER_SMOOTH_SCROLL)
		}
	}
}

func handleHotkey(msg *MSG) bool {
	if msg.Message != WM_KEYDOWN {
		return false
	}
	key := uint32(msg.WParam)
	ctrl, _, _ := procGetKeyState.Call(VK_CONTROL)
	shift, _, _ := procGetKeyState.Call(VK_SHIFT)
	isCtrl := int16(ctrl) < 0
	isShift := int16(shift) < 0
	if msg.Hwnd == app.renameEdit {
		if key == VK_RETURN {
			commitRename()
			return true
		}
		if key == VK_ESCAPE {
			cancelRename()
			return true
		}
	}
	if key == VK_ESCAPE && app.contextVisible {
		closeContextMenu()
		return true
	}
	if key == VK_F1 {
		if app.shortcutsVisible {
			closeShortcuts()
		} else {
			openShortcuts()
		}
		return true
	}
	if app.shortcutsVisible {
		if key == VK_ESCAPE {
			closeShortcuts()
		}
		return true
	}
	if key == VK_ESCAPE && app.onboarding && app.tutorialRevisit {
		closeTutorial()
		return true
	}
	if key == VK_F2 && !app.onboarding {
		beginRename()
		return true
	}
	if !isCtrl {
		return false
	}
	switch key {
	case 'N':
		newDocument()
		return true
	case 'O':
		openDialog()
		return true
	case 'S':
		if isShift {
			saveAsCurrent()
		} else {
			resolveManualSave()
		}
		return true
	case 'W':
		closeTab(app.active)
		return true
	case VK_TAB:
		if len(app.docs) > 1 {
			n := app.active + 1
			if isShift {
				n = app.active - 1
				if n < 0 {
					n = len(app.docs) - 1
				}
			} else if n >= len(app.docs) {
				n = 0
			}
			switchTab(n)
		}
		return true
	case 'T':
		if isShift {
			reopenClosed()
			return true
		}
	}
	return false
}

func wndProc(hwnd syscall.Handle, msg uint32, wparam, lparam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		return 0
	case WM_SIZE:
		layout()
		invalidate()
		return 0
	case WM_PAINT:
		paint()
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_SETFOCUS:
		if !app.onboarding && !app.shortcutsVisible && app.editor != 0 && activeDoc() != nil {
			procSetFocus.Call(uintptr(app.editor))
		}
		return 0
	case WM_MOUSEMOVE:
		x, y := signedWord(lparam), int32(int16((lparam>>16)&0xffff))
		handleTabDrag(x, y)
		handleSidebarDrag(x, y)
		handleMouseMove(x, y)
		return 0
	case WM_MOUSELEAVE:
		clearHover()
		return 0
	case WM_LBUTTONDOWN:
		x, y := signedWord(lparam), int32(int16((lparam>>16)&0xffff))
		if app.shortcutsVisible {
			handleClick(x, y)
			return 0
		}
		if startTabDrag(x, y) {
			return 0
		}
		if startSidebarDrag(x, y) {
			return 0
		}
		handleClick(x, y)
		return 0
	case WM_LBUTTONUP:
		finishTabDrag()
		finishSidebarDrag()
		return 0
	case WM_RBUTTONUP:
		handleRightClick(signedWord(lparam), int32(int16((lparam>>16)&0xffff)))
		return 0
	case WM_CAPTURECHANGED:
		app.dragTab = -1
		app.dragVisualX = 0
		app.dragging = false
		app.dragMoved = false
		app.sidebarDrag = -1
		app.sidebarDragVisualY = 0
		app.sidebarDragging = false
		app.sidebarDragMoved = false
		return 0
	case WM_EXITSIZEMOVE:
		rememberWindowPlacement()
		_ = saveConfig(app.cfg)
		return 0
	case WM_MBUTTONDOWN:
		handleMiddleClick(signedWord(lparam), int32(int16((lparam>>16)&0xffff)))
		return 0
	case WM_MOUSEWHEEL:
		pt := POINT{X: signedWord(lparam), Y: int32(int16((lparam >> 16) & 0xffff))}
		procScreenToClient.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&pt)))
		handleWheel(int16((wparam>>16)&0xffff), pt.X, pt.Y)
		return 0
	case WM_COMMAND:
		id := int(loWord(wparam))
		code := hiWord(wparam)
		if id == IDC_EDITOR && code == EN_CHANGE && !app.suppress {
			// Do not copy the entire RichEdit buffer synchronously on every keystroke.
			// The recovery/autosave debounce timers take one snapshot after typing settles.
			if d := activeDoc(); d != nil {
				d.Revision++
			}
			app.saveStatus = "Saving…"
			scheduleRecovery()
			scheduleAutosave()
			schedulePreview()
			// Only the status bar changes on a keystroke. Repainting the whole custom
			// shell hundreds of times per second was the source of the typing flicker.
			invalidateStatus()
			return 0
		}
		if id == IDC_RENAME && code == EN_KILLFOCUS {
			commitRename()
			return 0
		}
	case WM_NOTIFY:
		if lparam != 0 {
			hdr := (*NMHDR)(unsafe.Pointer(lparam))
			if hdr.HwndFrom == app.preview && hdr.Code == EN_LINK {
				el := (*ENLINK)(unsafe.Pointer(lparam))
				if el.Msg == WM_LBUTTONUP {
					openPreviewLinkAt(el.Chrg.CpMin, el.Chrg.CpMax)
					// Prevent the read-only preview from turning the click into a selection.
					return 1
				}
			}
		}
		return 0
	case WM_TIMER:
		handleTimer(wparam)
		return 0
	case WM_APP_IO_RESULT:
		handleIOResults()
		return 0
	case WM_CTLCOLOREDIT:
		p := colors()
		hdc := syscall.Handle(wparam)
		procSetTextColor.Call(uintptr(hdc), uintptr(p.text))
		procSetBkMode.Call(uintptr(hdc), TRANSPARENT)
		if app.editorBrush != 0 {
			return uintptr(app.editorBrush)
		}
		b, _, _ := procCreateSolidBrush.Call(uintptr(p.editorBg))
		app.editorBrush = syscall.Handle(b)
		return b
	case WM_CLOSE:
		rememberWindowPlacement()
		_ = saveConfig(app.cfg)
		saveAll()
		procDefWindowProc.Call(uintptr(hwnd), uintptr(msg), wparam, lparam)
		return 0
	case WM_DESTROY:
		stopSidebarFolderWatcher()
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProc.Call(uintptr(hwnd), uintptr(msg), wparam, lparam)
	return r
}

func startupFailure(stage string, err any) {
	f, _ := os.OpenFile(filepath.Join(os.TempDir(), "Typora-v4.20.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if f != nil {
		fmt.Fprintf(f, "%s FAILED %s: %v\n%s\n", time.Now().Format(time.RFC3339Nano), stage, err, debug.Stack())
		f.Close()
	}
	message(fmt.Sprintf("Typora could not start.\n\nStage: %s\n%v\n\nLog: %%TEMP%%\\Typora-v4.19.log", stage, err), "Typora startup error", MB_OK|MB_ICONWARNING)
}

func loadAppIcon(hInst uintptr, size int32) syscall.Handle {
	// The packaged executable contains icon group resource #1. Load it from the
	// executable itself so the title-bar/taskbar icon works even when users only
	// copy Typora.exe and do not keep Typora.ico beside it.
	if h, _, _ := procLoadImage.Call(hInst, 1, IMAGE_ICON, uintptr(size), uintptr(size), 0); h != 0 {
		return syscall.Handle(h)
	}
	// Developer/unbranded fallback.
	icoPath := filepath.Join(filepath.Dir(os.Args[0]), "Typora.ico")
	if h, _, _ := procLoadImage.Call(0, uintptr(unsafe.Pointer(wstr(icoPath))), IMAGE_ICON, uintptr(size), uintptr(size), LR_LOADFROMFILE); h != 0 {
		return syscall.Handle(h)
	}
	return 0
}

func main() {
	// Win32 windows, message queues, and COM dialogs are thread-affine.
	// Keep the entire UI/message pump on one OS thread for the lifetime of the app.
	runtime.LockOSThread()
	f, _ := os.OpenFile(filepath.Join(os.TempDir(), "Typora-v4.20.log"), os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0644)
	if f != nil {
		log.SetOutput(f)
		defer f.Close()
	}
	log.Printf("Typora %s native starting", appVersion)
	defer func() {
		if r := recover(); r != nil {
			startupFailure("panic", r)
		}
	}()
	procSetProcessDPIAware.Call()
	log.Printf("Loading native RichEdit")
	err := msftedit.Load()
	if err != nil {
		startupFailure("loading native RichEdit", err)
		return
	}
	log.Printf("RichEdit loaded")
	app.cfg = loadConfig()
	app.view = app.cfg.View
	log.Printf("Config loaded view=%s version=%d", app.view, app.cfg.Version)
	if app.view == "" {
		app.view = "edit"
	}
	app.closed = loadClosed()
	app.active = -1
	app.dragTab = -1
	app.sidebarDrag = -1
	ensureDefaultFolder()
	app.onboarding = !app.cfg.Onboarded
	hInst, _, _ := procGetModuleHandle.Call(0)
	cursor, _, _ := procLoadCursor.Call(0, IDC_ARROW)
	app.iconBig = loadAppIcon(hInst, 32)
	app.iconSmall = loadAppIcon(hInst, 16)
	app.iconHeader = loadAppIcon(hInst, 24)
	className := wstr("TyporaNativeV413Window")
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(wndProc), HInstance: syscall.Handle(hInst), HIcon: app.iconBig, HCursor: syscall.Handle(cursor), HbrBackground: syscall.Handle(COLOR_WINDOW + 1), LpszClassName: className, HIconSm: app.iconSmall}
	if r, _, e := procRegisterClassEx.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		startupFailure("registering window class", e)
		return
	}
	contextClassName := wstr("TyporaContextMenuV413")
	contextWC := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(contextMenuWndProc), HInstance: syscall.Handle(hInst), HCursor: syscall.Handle(cursor), LpszClassName: contextClassName}
	if r, _, e := procRegisterClassEx.Call(uintptr(unsafe.Pointer(&contextWC))); r == 0 {
		startupFailure("registering context menu class", e)
		return
	}
	px, py, pw, ph, startMaximized, havePlacement := startupWindowPlacement()
	xArg, yArg := uintptr(CW_USEDEFAULT), uintptr(CW_USEDEFAULT)
	if havePlacement {
		xArg = uintptr(int64(px))
		yArg = uintptr(int64(py))
		log.Printf("Restoring window placement x=%d y=%d w=%d h=%d maximized=%v", px, py, pw, ph, startMaximized)
	} else {
		pw, ph = 1360, 860
		log.Printf("No usable saved window placement; using Windows default")
	}
	hwnd, _, e := procCreateWindowEx.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(wstr(appName))), WS_OVERLAPPEDWINDOW|WS_VISIBLE|WS_CLIPCHILDREN, xArg, yArg, uintptr(pw), uintptr(ph), 0, 0, hInst, 0)
	if hwnd == 0 {
		startupFailure("creating main window", e)
		return
	}
	app.hwnd = syscall.Handle(hwnd)
	startIOWorkers()
	log.Printf("Main window created hwnd=0x%x", hwnd)
	app.fontUI = createFont(16, 400, "Segoe UI")
	app.fontUISemibold = createFont(18, 600, "Segoe UI Semibold")
	app.fontSmall = createFont(13, 400, "Segoe UI")
	app.fontMono = createFont(15, 400, "Cascadia Mono")
	app.editor = createChild("RICHEDIT50W", WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_TABSTOP|ES_MULTILINE|ES_AUTOVSCROLL|ES_NOHIDESEL|ES_WANTRETURN, IDC_EDITOR)
	app.preview = createChild("RICHEDIT50W", WS_CHILD|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, IDC_PREVIEW)
	if app.editor == 0 || app.preview == 0 {
		startupFailure("creating editor controls", errors.New("RichEdit child window creation failed"))
		return
	}
	send(app.editor, WM_SETFONT, uintptr(app.fontMono), 1)
	send(app.preview, WM_SETFONT, uintptr(app.fontUI), 1)
	setEditorStyle()
	installRichEditSubclasses()
	log.Printf("Editor controls created")
	if app.iconBig != 0 {
		send(app.hwnd, WM_SETICON, ICON_BIG, uintptr(app.iconBig))
	}
	if app.iconSmall != 0 {
		send(app.hwnd, WM_SETICON, ICON_SMALL, uintptr(app.iconSmall))
	}
	refreshSidebar()
	startSidebarFolderWatcher(app.cfg.DefaultFolder)
	layout()
	showCmd := uintptr(SW_SHOWNORMAL)
	if startMaximized && havePlacement {
		showCmd = SW_SHOWMAXIMIZED
	}
	procShowWindow.Call(hwnd, showCmd)
	procUpdateWindow.Call(hwnd)
	log.Printf("Window shown onboarding=%v", app.onboarding)
	if !app.onboarding {
		restoreSession()
		for _, d := range app.docs {
			queueDiskSave(d, false, false)
		}
		layout()
		if activeDoc() != nil {
			procSetFocus.Call(uintptr(app.editor))
		} else {
			procSetFocus.Call(uintptr(app.hwnd))
		}
	} else {
		app.saveStatus = "First-run setup"
		invalidate()
	}
	if len(os.Args) > 1 && !app.onboarding {
		if st, er := os.Stat(os.Args[1]); er == nil && !st.IsDir() {
			openFile(os.Args[1])
		}
	}
	log.Printf("Entering message loop docs=%d active=%d", len(app.docs), app.active)
	var m MSG
	for {
		r, _, _ := procGetMessage.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if handleHotkey(&m) {
			continue
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		procDispatchMessage.Call(uintptr(unsafe.Pointer(&m)))
	}
	if app.editorBrush != 0 {
		procDeleteObject.Call(uintptr(app.editorBrush))
	}
	for _, h := range []syscall.Handle{app.fontUI, app.fontUISemibold, app.fontSmall, app.fontMono} {
		if h != 0 {
			procDeleteObject.Call(uintptr(h))
		}
	}
}
