from __future__ import annotations
import struct, sys
from pathlib import Path


def align(v,a): return (v + a - 1) // a * a

def parse_ico(path):
    b=Path(path).read_bytes()
    reserved, typ, count=struct.unpack_from('<HHH',b,0)
    if reserved!=0 or typ!=1 or not count: raise ValueError('not an icon')
    imgs=[]
    entries=[]
    for i in range(count):
        off=6+i*16
        width,height,color,res,planes,bpp,size,img_off=struct.unpack_from('<BBBBHHII',b,off)
        img=b[img_off:img_off+size]
        imgs.append(img)
        # ICO files produced by modern image libraries commonly store wPlanes=0.
        # That is tolerated when loading the .ico directly, but Explorer's PE icon
        # extractor is stricter about RT_GROUP_ICON metadata. Advertise one color
        # plane in the group resource so the on-disk EXE gets its real shell icon.
        group_planes = planes or 1
        group_bpp = bpp or 32
        entries.append((width,height,color,res,group_planes,group_bpp,size,i+1))
    grp=bytearray(struct.pack('<HHH',0,1,count))
    for e in entries:
        width,height,color,res,planes,bpp,size,rid=e
        grp += struct.pack('<BBBBHHIH',width,height,color,res,planes,bpp,size,rid)
    return imgs, bytes(grp)

def make_resources(icon_imgs, group_data, base_rva):
    n=len(icon_imgs)
    # layout directory structures
    root_off=0
    root_size=16+2*8
    icon_type_off=root_off+root_size
    icon_type_size=16+n*8
    group_type_off=icon_type_off+icon_type_size
    group_type_size=16+1*8
    icon_lang_off=group_type_off+group_type_size
    icon_lang_offsets=[icon_lang_off+i*24 for i in range(n)]
    group_lang_off=icon_lang_off+n*24
    data_entries_off=group_lang_off+24
    data_entry_offsets=[data_entries_off+i*16 for i in range(n+1)]
    data_blob_off=align(data_entries_off+(n+1)*16,4)

    buf=bytearray(data_blob_off)
    def dir_header(off, ids): struct.pack_into('<IIHHHH',buf,off,0,0,0,0,0,ids)
    def entry(off, ident, target, is_dir): struct.pack_into('<II',buf,off,ident,(target | (0x80000000 if is_dir else 0)))

    dir_header(root_off,2)
    entry(root_off+16,3,icon_type_off,True)
    entry(root_off+24,14,group_type_off,True)

    dir_header(icon_type_off,n)
    for i,langoff in enumerate(icon_lang_offsets):
        entry(icon_type_off+16+i*8,i+1,langoff,True)
    dir_header(group_type_off,1)
    entry(group_type_off+16,1,group_lang_off,True)

    for i,langoff in enumerate(icon_lang_offsets):
        dir_header(langoff,1)
        entry(langoff+16,1033,data_entry_offsets[i],False)
    dir_header(group_lang_off,1)
    entry(group_lang_off+16,1033,data_entry_offsets[n],False)

    cursor=data_blob_off
    blobs=list(icon_imgs)+[group_data]
    for i,blob in enumerate(blobs):
        cursor=align(cursor,4)
        if len(buf)<cursor: buf.extend(b'\0'*(cursor-len(buf)))
        dataoff=cursor
        buf.extend(blob); cursor += len(blob)
        # data entry points to absolute RVA of payload
        struct.pack_into('<IIII',buf,data_entry_offsets[i],base_rva+dataoff,len(blob),0,0)
    return bytes(buf)

def patch(exe,ico,out):
    data=bytearray(Path(exe).read_bytes())
    pe=struct.unpack_from('<I',data,0x3c)[0]
    if data[pe:pe+4]!=b'PE\0\0': raise ValueError('not PE')
    nsec=struct.unpack_from('<H',data,pe+6)[0]
    size_opt=struct.unpack_from('<H',data,pe+20)[0]
    opt=pe+24
    magic=struct.unpack_from('<H',data,opt)[0]
    if magic!=0x20b: raise ValueError('expected PE32+')
    sec_align=struct.unpack_from('<I',data,opt+32)[0]
    file_align=struct.unpack_from('<I',data,opt+36)[0]
    size_headers=struct.unpack_from('<I',data,opt+60)[0]
    sec_table=opt+size_opt
    new_hdr=sec_table+nsec*40
    if new_hdr+40>size_headers:
        raise ValueError('no room for another section header')
    last_end_va=0; last_end_raw=0
    for i in range(nsec):
        sh=sec_table+i*40
        vs,va,rs,rp=struct.unpack_from('<IIII',data,sh+8)
        last_end_va=max(last_end_va,va+align(max(vs,rs),sec_align))
        last_end_raw=max(last_end_raw,rp+rs)
    new_va=align(last_end_va,sec_align)
    imgs,grp=parse_ico(ico)
    rsrc=make_resources(imgs,grp,new_va)
    raw_size=align(len(rsrc),file_align)
    raw_ptr=align(max(len(data),last_end_raw),file_align)
    if len(data)<raw_ptr: data.extend(b'\0'*(raw_ptr-len(data)))
    data.extend(rsrc)
    if len(rsrc)<raw_size: data.extend(b'\0'*(raw_size-len(rsrc)))

    # section header
    name=b'.rsrc\0\0\0'
    data[new_hdr:new_hdr+8]=name
    struct.pack_into('<IIIIIIHHI',data,new_hdr+8,len(rsrc),new_va,raw_size,raw_ptr,0,0,0,0,0x40000040)
    struct.pack_into('<H',data,pe+6,nsec+1)
    struct.pack_into('<I',data,opt+56,align(new_va+len(rsrc),sec_align))
    init_size=struct.unpack_from('<I',data,opt+8)[0]
    struct.pack_into('<I',data,opt+8,init_size+raw_size)
    # Resource data directory index 2 (PE32+ directories start at opt+112)
    struct.pack_into('<II',data,opt+112+2*8,new_va,len(rsrc))
    Path(out).write_bytes(data)

if __name__=='__main__':
    patch(sys.argv[1],sys.argv[2],sys.argv[3])
