//go:build windows

package main

import (
	"errors"
	"fmt"
	"path/filepath"
	"runtime"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

const (
	CLSCTX_INPROC_SERVER     = 0x00000001
	COINIT_APARTMENTTHREADED = 0x00000002
	FOS_OVERWRITEPROMPT      = 0x00000002
	FOS_STRICTFILETYPES      = 0x00000004
	FOS_NOCHANGEDIR          = 0x00000008
	FOS_PICKFOLDERS          = 0x00000020
	FOS_FORCEFILESYSTEM      = 0x00000040
	FOS_PATHMUSTEXIST        = 0x00000800
	FOS_FILEMUSTEXIST        = 0x00001000
	SIGDN_FILESYSPATH        = 0x80058000
)

type GUID struct {
	Data1 uint32
	Data2 uint16
	Data3 uint16
	Data4 [8]byte
}
type COMDLG_FILTERSPEC struct {
	Name *uint16
	Spec *uint16
}
type iFileDialog struct{ Vtbl *[27]uintptr }
type iShellItem struct{ Vtbl *[8]uintptr }

var (
	CLSIDFileOpenDialog = GUID{0xDC1C5A9C, 0xE88A, 0x4DDE, [8]byte{0xA5, 0xA1, 0x60, 0xF8, 0x2A, 0x20, 0xAE, 0xF7}}
	IIDFileOpenDialog   = GUID{0xD57C7288, 0xD4AD, 0x4768, [8]byte{0xBE, 0x02, 0x9D, 0x96, 0x95, 0x32, 0xD9, 0x60}}
	CLSIDFileSaveDialog = GUID{0xC0B4E2F3, 0xBA21, 0x4773, [8]byte{0x8D, 0xBA, 0x33, 0x5E, 0xC9, 0x46, 0xEB, 0x8B}}
	IIDFileSaveDialog   = GUID{0x84BCCD23, 0x5FDE, 0x4CDB, [8]byte{0xAE, 0xA4, 0xAF, 0x64, 0xB8, 0x3D, 0x78, 0xAB}}
	IIDIShellItem       = GUID{0x43826D1E, 0xE718, 0x42EE, [8]byte{0xBC, 0x55, 0xA1, 0xE2, 0x61, 0xC3, 0x7B, 0xFE}}

	shell32                         = syscall.NewLazyDLL("shell32.dll")
	ole32                           = syscall.NewLazyDLL("ole32.dll")
	procCoInitializeEx              = ole32.NewProc("CoInitializeEx")
	procCoUninitialize              = ole32.NewProc("CoUninitialize")
	procCoCreateInstance            = ole32.NewProc("CoCreateInstance")
	procCoTaskMemFree               = ole32.NewProc("CoTaskMemFree")
	procSHCreateItemFromParsingName = shell32.NewProc("SHCreateItemFromParsingName")
)

func hresultFailed(hr uintptr) bool { return int32(uint32(hr)) < 0 }
func hresultHex(hr uintptr) string  { return fmt.Sprintf("0x%08X", uint32(hr)) }
func comCall(method uintptr, args ...uintptr) uintptr {
	r, _, _ := syscall.SyscallN(method, args...)
	return r
}

func utf16PtrToString(p *uint16) string {
	if p == nil {
		return ""
	}
	buf := make([]uint16, 0, 260)
	for i := uintptr(0); ; i++ {
		v := *(*uint16)(unsafe.Pointer(uintptr(unsafe.Pointer(p)) + i*2))
		if v == 0 {
			break
		}
		buf = append(buf, v)
	}
	return string(utf16.Decode(buf))
}

func comRelease(obj unsafe.Pointer) {
	if obj != nil {
		p := (*iFileDialog)(obj)
		comCall(p.Vtbl[2], uintptr(obj))
	}
}
func shellItemRelease(item *iShellItem) {
	if item != nil {
		comCall(item.Vtbl[2], uintptr(unsafe.Pointer(item)))
	}
}

func shellItemForPath(path string) *iShellItem {
	if path == "" {
		return nil
	}
	w := syscall.StringToUTF16(path)
	var item *iShellItem
	hr, _, _ := procSHCreateItemFromParsingName.Call(uintptr(unsafe.Pointer(&w[0])), 0, uintptr(unsafe.Pointer(&IIDIShellItem)), uintptr(unsafe.Pointer(&item)))
	runtime.KeepAlive(w)
	if hresultFailed(hr) {
		return nil
	}
	return item
}
func pathFromShellItem(item *iShellItem) (string, error) {
	if item == nil {
		return "", errors.New("no item selected")
	}
	var raw *uint16
	hr := comCall(item.Vtbl[5], uintptr(unsafe.Pointer(item)), uintptr(SIGDN_FILESYSPATH), uintptr(unsafe.Pointer(&raw)))
	if hresultFailed(hr) || raw == nil {
		return "", fmt.Errorf("GetDisplayName failed (%s)", hresultHex(hr))
	}
	defer procCoTaskMemFree.Call(uintptr(unsafe.Pointer(raw)))
	return utf16PtrToString(raw), nil
}
func createFileDialog(save bool) (*iFileDialog, error) {
	var obj *iFileDialog
	clsid := &CLSIDFileOpenDialog
	iid := &IIDFileOpenDialog
	if save {
		clsid = &CLSIDFileSaveDialog
		iid = &IIDFileSaveDialog
	}
	hr, _, _ := procCoCreateInstance.Call(uintptr(unsafe.Pointer(clsid)), 0, CLSCTX_INPROC_SERVER, uintptr(unsafe.Pointer(iid)), uintptr(unsafe.Pointer(&obj)))
	if hresultFailed(hr) || obj == nil {
		return nil, fmt.Errorf("CoCreateInstance failed (%s)", hresultHex(hr))
	}
	return obj, nil
}
func dialogSetTitle(d *iFileDialog, s string) {
	w := syscall.StringToUTF16(s)
	comCall(d.Vtbl[17], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&w[0])))
	runtime.KeepAlive(w)
}
func dialogSetFolder(d *iFileDialog, p string) {
	item := shellItemForPath(p)
	if item == nil {
		return
	}
	defer shellItemRelease(item)
	comCall(d.Vtbl[12], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(item)))
}
func dialogSetTypes(d *iFileDialog) {
	names := [][]uint16{syscall.StringToUTF16("Markdown files (*.md; *.markdown)"), syscall.StringToUTF16("Text files (*.txt)"), syscall.StringToUTF16("All files (*.*)")}
	specs := [][]uint16{syscall.StringToUTF16("*.md;*.markdown"), syscall.StringToUTF16("*.txt"), syscall.StringToUTF16("*.*")}
	f := []COMDLG_FILTERSPEC{{&names[0][0], &specs[0][0]}, {&names[1][0], &specs[1][0]}, {&names[2][0], &specs[2][0]}}
	comCall(d.Vtbl[4], uintptr(unsafe.Pointer(d)), uintptr(len(f)), uintptr(unsafe.Pointer(&f[0])))
	comCall(d.Vtbl[5], uintptr(unsafe.Pointer(d)), 1)
	runtime.KeepAlive(names)
	runtime.KeepAlive(specs)
	runtime.KeepAlive(f)
}

func withCOM(fn func() (string, error)) (string, error) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	hr, _, _ := procCoInitializeEx.Call(0, COINIT_APARTMENTTHREADED)
	if !hresultFailed(hr) {
		defer procCoUninitialize.Call()
	}
	return fn()
}

func pickMarkdownFile(owner syscall.Handle, initial string) (string, error) {
	return withCOM(func() (string, error) {
		d, err := createFileDialog(false)
		if err != nil {
			return "", err
		}
		defer comRelease(unsafe.Pointer(d))
		var opts uint32
		hr := comCall(d.Vtbl[10], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&opts)))
		if hresultFailed(hr) {
			return "", fmt.Errorf("GetOptions %s", hresultHex(hr))
		}
		opts |= FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST | FOS_FILEMUSTEXIST | FOS_NOCHANGEDIR
		comCall(d.Vtbl[9], uintptr(unsafe.Pointer(d)), uintptr(opts))
		dialogSetTypes(d)
		dialogSetFolder(d, initial)
		dialogSetTitle(d, "Open Markdown or text file")
		hr = comCall(d.Vtbl[3], uintptr(unsafe.Pointer(d)), uintptr(owner))
		if uint32(hr) == 0x800704C7 {
			return "", errors.New("cancelled")
		}
		if hresultFailed(hr) {
			return "", fmt.Errorf("dialog %s", hresultHex(hr))
		}
		var item *iShellItem
		hr = comCall(d.Vtbl[20], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&item)))
		if hresultFailed(hr) || item == nil {
			return "", fmt.Errorf("GetResult %s", hresultHex(hr))
		}
		defer shellItemRelease(item)
		return pathFromShellItem(item)
	})
}

func pickFolder(owner syscall.Handle, initial string) (string, error) {
	return withCOM(func() (string, error) {
		d, err := createFileDialog(false)
		if err != nil {
			return "", err
		}
		defer comRelease(unsafe.Pointer(d))
		var opts uint32
		hr := comCall(d.Vtbl[10], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&opts)))
		if hresultFailed(hr) {
			return "", fmt.Errorf("GetOptions %s", hresultHex(hr))
		}
		opts |= FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST | FOS_NOCHANGEDIR
		comCall(d.Vtbl[9], uintptr(unsafe.Pointer(d)), uintptr(opts))
		dialogSetFolder(d, initial)
		dialogSetTitle(d, "Choose your default notes folder")
		hr = comCall(d.Vtbl[3], uintptr(unsafe.Pointer(d)), uintptr(owner))
		if uint32(hr) == 0x800704C7 {
			return "", errors.New("cancelled")
		}
		if hresultFailed(hr) {
			return "", fmt.Errorf("dialog %s", hresultHex(hr))
		}
		var item *iShellItem
		hr = comCall(d.Vtbl[20], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&item)))
		if hresultFailed(hr) || item == nil {
			return "", fmt.Errorf("GetResult %s", hresultHex(hr))
		}
		defer shellItemRelease(item)
		return pathFromShellItem(item)
	})
}

func saveAsDialog(owner syscall.Handle, initial, filename string) (string, error) {
	return withCOM(func() (string, error) {
		d, err := createFileDialog(true)
		if err != nil {
			return "", err
		}
		defer comRelease(unsafe.Pointer(d))
		var opts uint32
		hr := comCall(d.Vtbl[10], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&opts)))
		if hresultFailed(hr) {
			return "", fmt.Errorf("GetOptions %s", hresultHex(hr))
		}
		opts |= FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST | FOS_OVERWRITEPROMPT | FOS_STRICTFILETYPES | FOS_NOCHANGEDIR
		comCall(d.Vtbl[9], uintptr(unsafe.Pointer(d)), uintptr(opts))
		dialogSetTypes(d)
		dialogSetFolder(d, initial)
		dialogSetTitle(d, "Save As")
		ext := syscall.StringToUTF16("md")
		comCall(d.Vtbl[22], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&ext[0])))
		if filename == "" {
			filename = "Untitled 01.md"
		}
		if filepath.Ext(filename) == "" {
			filename += ".md"
		}
		w := syscall.StringToUTF16(filename)
		comCall(d.Vtbl[15], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&w[0])))
		runtime.KeepAlive(ext)
		runtime.KeepAlive(w)
		hr = comCall(d.Vtbl[3], uintptr(unsafe.Pointer(d)), uintptr(owner))
		if uint32(hr) == 0x800704C7 {
			return "", errors.New("cancelled")
		}
		if hresultFailed(hr) {
			return "", fmt.Errorf("dialog %s", hresultHex(hr))
		}
		var item *iShellItem
		hr = comCall(d.Vtbl[20], uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(&item)))
		if hresultFailed(hr) || item == nil {
			return "", fmt.Errorf("GetResult %s", hresultHex(hr))
		}
		defer shellItemRelease(item)
		return pathFromShellItem(item)
	})
}

const (
	TDF_ALLOW_DIALOG_CANCELLATION   = 0x0008
	TDF_POSITION_RELATIVE_TO_WINDOW = 0x1000
	TDF_SIZE_TO_CONTENT             = 0x01000000
	TDCBF_YES_BUTTON                = 0x0002
	TDCBF_CANCEL_BUTTON             = 0x0008
	TDCBF_OK_BUTTON                 = 0x0001

	FO_DELETE          = 0x0003
	FOF_NOCONFIRMATION = 0x0010
	FOF_ALLOWUNDO      = 0x0040
	FOF_NOERRORUI      = 0x0400
)

type TASKDIALOGCONFIG struct {
	CbSize                  uint32
	HwndParent              syscall.Handle
	HInstance               syscall.Handle
	DwFlags                 uint32
	DwCommonButtons         uint32
	PszWindowTitle          *uint16
	HMainIcon               uintptr
	PszMainInstruction      *uint16
	PszContent              *uint16
	CButtons                uint32
	PButtons                uintptr
	NDefaultButton          int32
	CRadioButtons           uint32
	PRadioButtons           uintptr
	NDefaultRadioButton     int32
	PszVerificationText     *uint16
	PszExpandedInformation  *uint16
	PszExpandedControlText  *uint16
	PszCollapsedControlText *uint16
	HFooterIcon             uintptr
	PszFooter               *uint16
	PfCallback              uintptr
	LpCallbackData          uintptr
	CxWidth                 uint32
}

type SHFILEOPSTRUCTW struct {
	Hwnd                  syscall.Handle
	WFunc                 uint32
	PFrom                 *uint16
	PTo                   *uint16
	FFlags                uint16
	FAnyOperationsAborted int32
	HNameMappings         uintptr
	LpszProgressTitle     *uint16
}

var (
	comctl32               = syscall.NewLazyDLL("comctl32.dll")
	procTaskDialogIndirect = comctl32.NewProc("TaskDialogIndirect")
	procSHFileOperationW   = shell32.NewProc("SHFileOperationW")
)

func runTaskDialog(owner syscall.Handle, title, instruction, content, verification string, buttons uint32) (button int32, checked bool, ok bool) {
	// TaskDialogIndirect is only exposed by the v6 Common Controls DLL. Some
	// systems/process manifests resolve an older comctl32 where the procedure is
	// absent. Probe it first so a cosmetic dialog can never panic the application.
	if err := procTaskDialogIndirect.Find(); err != nil {
		return 0, false, false
	}
	wt := syscall.StringToUTF16(title)
	wi := syscall.StringToUTF16(instruction)
	wc := syscall.StringToUTF16(content)
	var wv []uint16
	cfg := TASKDIALOGCONFIG{
		HwndParent:         owner,
		DwFlags:            TDF_ALLOW_DIALOG_CANCELLATION | TDF_POSITION_RELATIVE_TO_WINDOW | TDF_SIZE_TO_CONTENT,
		DwCommonButtons:    buttons,
		PszWindowTitle:     &wt[0],
		PszMainInstruction: &wi[0],
		PszContent:         &wc[0],
	}
	if verification != "" {
		wv = syscall.StringToUTF16(verification)
		cfg.PszVerificationText = &wv[0]
	}
	cfg.CbSize = uint32(unsafe.Sizeof(cfg))
	var pressed int32
	var verify int32
	hr, _, _ := procTaskDialogIndirect.Call(
		uintptr(unsafe.Pointer(&cfg)),
		uintptr(unsafe.Pointer(&pressed)),
		0,
		uintptr(unsafe.Pointer(&verify)),
	)
	runtime.KeepAlive(wt)
	runtime.KeepAlive(wi)
	runtime.KeepAlive(wc)
	runtime.KeepAlive(wv)
	if hresultFailed(hr) {
		return 0, false, false
	}
	return pressed, verify != 0, true
}

func confirmCloseTab(owner syscall.Handle, title string) (closeTab bool, dontAskAgain bool) {
	pressed, checked, ok := runTaskDialog(
		owner,
		"Close tab",
		fmt.Sprintf("Close “%s”?", title),
		"This note has already been saved automatically. Closing the tab does not delete the file, and Ctrl+Shift+T can reopen recently closed tabs.",
		"Don't show this confirmation again",
		TDCBF_YES_BUTTON|TDCBF_CANCEL_BUTTON,
	)
	if ok {
		return pressed == IDYES, checked
	}
	// Keep the permanent opt-out even on systems where TaskDialog is unavailable.
	ans := message(
		fmt.Sprintf("Close \"%s\"?\n\nYes = close this tab\nNo = close and never show this confirmation again\nCancel = keep the tab open", title),
		"Close tab", MB_YESNOCANCEL|MB_ICONQUESTION,
	)
	switch ans {
	case IDYES:
		return true, false
	case IDNO:
		return true, true
	default:
		return false, false
	}
}

func showKeyboardShortcuts(owner syscall.Handle) {
	content := "Ctrl+N   New note\n" +
		"Ctrl+O   Open file\n" +
		"Ctrl+S   Save now\n" +
		"Ctrl+Shift+S   Save As…\n" +
		"Ctrl+W   Close tab\n" +
		"Ctrl+Tab   Next tab\n" +
		"Ctrl+Shift+Tab   Previous tab\n" +
		"Ctrl+Shift+T   Reopen closed tab\n" +
		"F2   Rename current note\n" +
		"Enter   Finish renaming\n" +
		"Esc   Cancel rename / close revisited tutorial\n" +
		"F1   Keyboard shortcuts\n\n" +
		"Mouse: drag tabs to reorder • middle-click a tab to close • right-click a tab or note to delete"
	if _, _, ok := runTaskDialog(owner, "Typora", "Keyboard shortcuts", content, "", TDCBF_OK_BUTTON); ok {
		return
	}
	message(content, "Keyboard shortcuts", MB_OK)
}

func confirmDeleteNote(owner syscall.Handle, title string) bool {
	pressed, _, ok := runTaskDialog(
		owner,
		"Delete note",
		fmt.Sprintf("Move “%s” to the Recycle Bin?", title),
		"Any open tab for this note will close. You can restore the file later from the Windows Recycle Bin.",
		"",
		TDCBF_YES_BUTTON|TDCBF_CANCEL_BUTTON,
	)
	if ok {
		return pressed == IDYES
	}
	return message(fmt.Sprintf("Move \"%s\" to the Recycle Bin?", title), "Delete note", MB_OKCANCEL|MB_ICONWARNING) == IDOK
}

func recycleFile(owner syscall.Handle, path string) error {
	if path == "" {
		return errors.New("no file path")
	}
	from := syscall.StringToUTF16(filepath.Clean(path))
	// SHFileOperation requires a double-NUL terminated multi-string.
	from = append(from, 0)
	op := SHFILEOPSTRUCTW{
		Hwnd:   owner,
		WFunc:  FO_DELETE,
		PFrom:  &from[0],
		FFlags: FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI,
	}
	r, _, _ := procSHFileOperationW.Call(uintptr(unsafe.Pointer(&op)))
	runtime.KeepAlive(from)
	if r != 0 {
		return fmt.Errorf("Windows could not move the file to the Recycle Bin (code %d)", r)
	}
	if op.FAnyOperationsAborted != 0 {
		return errors.New("delete cancelled")
	}
	return nil
}
