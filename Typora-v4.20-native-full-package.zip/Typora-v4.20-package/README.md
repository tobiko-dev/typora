# Typora 4.20 — personal native build

A fast, local-first native Windows Markdown editor prototype. This is an independent personal project and is not the commercial Typora application.

## What changed in 4.20

- The Markdown Preview pane now paints into an off-screen buffer before presenting each frame, so RichEdit text and the custom rounded fenced-code blocks appear together instead of in two visible passes.
- Preview background erasing is suppressed to prevent flashes while scrolling.
- Smooth scrolling no longer forces an extra full-pane invalidation on every animation tick.
- v4.19's exact preview scroll-position preservation while typing remains intact.
- The live Notes-folder watcher and external-deletion safety from v4.17/v4.18 remain intact.


## Core workflow

- New tabs begin as `Untitled 01`, `Untitled 02`, and so on, with the title selected for immediate renaming.
- Notes continuously save to the chosen default notes folder.
- Recovery buffers are kept separately from the real Markdown files.
- **Ctrl+S** flushes immediately; **Ctrl+Shift+S** opens the native Windows Save As dialog.
- Tabs/session buffers return on the next launch.
- **Ctrl+Shift+T** reopens a recently closed tab.
- Drag top tabs or sidebar notes to reorder them.
- Middle-click closes a top tab; right-click tabs/sidebar notes for contextual actions.
- **F1** opens the in-app shortcut sheet; **?** reopens the tutorial.

## Code fences

Plain block:

    ```
    something
    ```

Language-aware block:

    ```json
    {"order_id": 98124}
    ```

Fenced blocks are now custom-painted native preview cards rather than RichEdit background ranges. The language label is intentionally small and the language controls syntax coloring. Inline code remains compact: `` `something` ``.

## Sidebar ordering

Dragging files in the left Notes list creates a custom order. Right-click and choose **Sort notes A–Z** whenever you want to return to alphabetical order.

## Folders

v4.20 still displays files from the selected notes-folder root only. Nested folders are deliberately not flattened into the list. A future folder feature should be a proper collapsible tree.

## Diagnostics

Startup/runtime log: `%TEMP%\Typora-v4.20.log`


### External deletion safety

If an open note is deleted in Explorer, Typora keeps the tab buffer for safety but suspends background saving to that path. It will not recreate the deleted file. Use Ctrl+S to explicitly restore it or Ctrl+Shift+S to save the buffer elsewhere.
