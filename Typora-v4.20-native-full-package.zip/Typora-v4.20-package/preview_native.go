//go:build windows

package main

import (
	"regexp"
	"strings"
	"syscall"
	"unicode/utf16"
	"unicode/utf8"
	"unsafe"
)

// Native preview rendering intentionally avoids RichEdit EM_STREAMIN. Earlier
// builds fed RTF through a Go callback; a fault in that callback path could
// terminate the process inside RichEdit. v4.8 builds ordinary Unicode text and
// applies formatting ranges with regular RichEdit messages instead.

const (
	// RichEdit 3.0+ pixel scroll position messages. The preview is RICHEDIT50W,
	// so these are supported and let live re-rendering preserve the exact viewport.
	EM_GETSCROLLPOS = 0x04DD
	EM_SETSCROLLPOS = 0x04DE
)

type previewSpan struct {
	start, end int
	bold       bool
	italic     bool
	underline  bool
	strike     bool
	size       int32
	face       string
	color      uint32
	colorSet   bool
	back       uint32
	backSet    bool
}

type previewLink struct {
	start, end int
	target     string
}

type previewCodeBlock struct {
	start, end int
	lines      []string
	lang       string
	label      string
}

type previewBuilder struct {
	b      strings.Builder
	pos    int // RichEdit logical selection index
	spans  []previewSpan
	links  []previewLink
	blocks []previewCodeBlock
}

func utf16Units(s string) int { return len(utf16.Encode([]rune(s))) }

// richEditSelectionUnits returns the logical character count used by RichEdit
// selection APIs. CRLF pairs count as one paragraph character there, even
// though WM_GETTEXT/SetWindowText commonly expose two code units.
func richEditSelectionUnits(s string) int {
	s = strings.ReplaceAll(s, "\r\n", "\n")
	s = strings.ReplaceAll(s, "\r", "\n")
	return utf16Units(s)
}

func (p *previewBuilder) raw(s string) (int, int) {
	start := p.pos
	p.b.WriteString(s)
	p.pos += utf16Units(s)
	return start, p.pos
}

func (p *previewBuilder) span(start, end int, style previewSpan) {
	if end <= start {
		return
	}
	style.start, style.end = start, end
	p.spans = append(p.spans, style)
}

func (p *previewBuilder) newline() {
	// RichEdit 2.0+ stores a CRLF paragraph break as one logical character for
	// EM_SETSEL/EM_EXSETSEL positioning. Keep CRLF in the text we hand to
	// SetWindowTextW, but advance the formatting position by exactly one UTF-16
	// code unit. Counting it as two makes every span drift by one character for
	// every preceding line, which is why headings used to spill into later text.
	p.b.WriteString("\r\n")
	p.pos++
}

func (p *previewBuilder) inline(s string, inherited previewSpan) {
	for len(s) > 0 {
		if strings.HasPrefix(s, "\\") && len(s) > 1 {
			_, sz := utf8.DecodeRuneInString(s[1:])
			p.raw(s[1 : 1+sz])
			s = s[1+sz:]
			continue
		}
		if strings.HasPrefix(s, "![") {
			if close := strings.Index(s, "]("); close >= 2 {
				if relEnd := strings.Index(s[close+2:], ")"); relEnd >= 0 {
					alt := s[2:close]
					target := s[close+2 : close+2+relEnd]
					st, en := p.raw("Image: " + alt + " — " + target)
					stl := inherited
					stl.italic = true
					stl.colorSet = true
					stl.color = colors().muted
					p.span(st, en, stl)
					s = s[close+3+relEnd:]
					continue
				}
			}
		}
		if strings.HasPrefix(s, "[") {
			if close := strings.Index(s, "]("); close >= 1 {
				if relEnd := strings.Index(s[close+2:], ")"); relEnd >= 0 {
					label := s[1:close]
					target := strings.TrimSpace(s[close+2 : close+2+relEnd])
					st := p.pos
					linkStyle := inherited
					linkStyle.underline = true
					linkStyle.colorSet = true
					linkStyle.color = colors().accent
					p.inline(label, linkStyle)
					p.span(st, p.pos, linkStyle)
					p.links = append(p.links, previewLink{start: st, end: p.pos, target: target})
					s = s[close+3+relEnd:]
					continue
				}
			}
		}
		if strings.HasPrefix(s, "**") || strings.HasPrefix(s, "__") {
			mark := s[:2]
			if j := strings.Index(s[2:], mark); j >= 0 {
				st := p.pos
				stl := inherited
				stl.bold = true
				p.inline(s[2:2+j], stl)
				p.span(st, p.pos, stl)
				s = s[4+j:]
				continue
			}
		}
		if strings.HasPrefix(s, "~~") {
			if j := strings.Index(s[2:], "~~"); j >= 0 {
				st := p.pos
				stl := inherited
				stl.strike = true
				p.inline(s[2:2+j], stl)
				p.span(st, p.pos, stl)
				s = s[4+j:]
				continue
			}
		}
		if strings.HasPrefix(s, "`") {
			if j := strings.Index(s[1:], "`"); j >= 0 {
				st, en := p.raw(s[1 : 1+j])
				stl := inherited
				stl.face = "Cascadia Mono"
				stl.size = 220
				stl.backSet = true
				stl.back = colors().panel2
				p.span(st, en, stl)
				s = s[2+j:]
				continue
			}
		}
		if strings.HasPrefix(s, "*") || strings.HasPrefix(s, "_") {
			mark := s[:1]
			if j := strings.Index(s[1:], mark); j > 0 {
				st := p.pos
				stl := inherited
				stl.italic = true
				p.inline(s[1:1+j], stl)
				p.span(st, p.pos, stl)
				s = s[2+j:]
				continue
			}
		}
		r, sz := utf8.DecodeRuneInString(s)
		if sz <= 0 {
			break
		}
		p.raw(string(r))
		s = s[sz:]
	}
}

type codeSyntaxColors struct {
	keyword uint32
	string_ uint32
	comment uint32
	number  uint32
	literal uint32
}

func syntaxColors() codeSyntaxColors {
	if app.cfg.Theme == "light" {
		return codeSyntaxColors{keyword: rgb(125, 70, 170), string_: rgb(35, 125, 72), comment: rgb(125, 132, 145), number: rgb(181, 92, 36), literal: rgb(45, 92, 190)}
	}
	return codeSyntaxColors{keyword: rgb(198, 120, 221), string_: rgb(152, 195, 121), comment: rgb(112, 120, 136), number: rgb(209, 154, 102), literal: rgb(97, 175, 239)}
}

func normalizeCodeLanguage(lang string) string {
	lang = strings.ToLower(strings.TrimSpace(lang))
	if i := strings.IndexAny(lang, " \t{"); i >= 0 {
		lang = lang[:i]
	}
	switch lang {
	case "py", "python3":
		return "python"
	case "js", "jsx", "node", "nodejs":
		return "javascript"
	case "ts", "tsx":
		return "typescript"
	case "sh", "shell", "zsh":
		return "bash"
	case "ps", "ps1":
		return "powershell"
	case "c++", "cc", "cxx":
		return "cpp"
	case "cs", "c#":
		return "csharp"
	case "rs":
		return "rust"
	case "kt", "kts":
		return "kotlin"
	case "yml":
		return "yaml"
	case "htm":
		return "html"
	case "svg":
		return "xml"
	}
	return lang
}

func codeLanguageLabel(raw, normalized string) string {
	if strings.TrimSpace(raw) == "" {
		return ""
	}
	switch normalized {
	case "javascript":
		return "JS"
	case "typescript":
		return "TS"
	case "python":
		return "PYTHON"
	case "cpp":
		return "C++"
	case "csharp":
		return "C#"
	case "powershell":
		return "POWERSHELL"
	case "bash":
		return "BASH"
	case "html":
		return "HTML"
	case "xml":
		return "XML"
	case "yaml":
		return "YAML"
	case "json":
		return "JSON"
	case "sql":
		return "SQL"
	}
	if normalized != "" {
		return strings.ToUpper(normalized)
	}
	return strings.ToUpper(strings.Fields(raw)[0])
}

func keywordRegex(words string) *regexp.Regexp {
	parts := strings.Fields(words)
	for i := range parts {
		parts[i] = regexp.QuoteMeta(parts[i])
	}
	return regexp.MustCompile(`\b(?:` + strings.Join(parts, "|") + `)\b`)
}

var codeKeywordRegex = map[string]*regexp.Regexp{
	"go":         keywordRegex("break default func interface select case defer go map struct chan else goto package switch const fallthrough if range type continue for import return var"),
	"python":     keywordRegex("and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield match case"),
	"javascript": keywordRegex("await break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return static super switch this throw try typeof var void while with yield async of"),
	"typescript": keywordRegex("abstract any as asserts async await boolean break case catch class const constructor continue debugger declare default delete do else enum export extends finally for from function get if implements import in infer instanceof interface is keyof let module namespace never new null number object of package private protected public readonly require return set static string super switch symbol this throw true try type typeof undefined unique unknown var void while with yield"),
	"java":       keywordRegex("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null"),
	"c":          keywordRegex("auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while"),
	"cpp":        keywordRegex("alignas alignof and asm auto bool break case catch char class concept const consteval constexpr continue co_await co_return decltype default delete do double dynamic_cast else enum explicit export extern false float for friend if inline int long mutable namespace new noexcept nullptr operator private protected public reinterpret_cast requires return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile while"),
	"csharp":     keywordRegex("abstract as base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach goto if implicit in int interface internal is lock long namespace new null object operator out override params private protected public readonly ref return sbyte sealed short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using virtual void volatile while async await var dynamic record init required"),
	"rust":       keywordRegex("as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while"),
	"swift":      keywordRegex("associatedtype class deinit enum extension fileprivate func import init inout internal let open operator private protocol public rethrows static struct subscript typealias var break case continue default defer do else fallthrough for guard if in repeat return switch where while as catch false is nil super self Self throw throws true try await async actor"),
	"kotlin":     keywordRegex("as break class continue do else false for fun if in interface is null object package return super this throw true try typealias typeof val var when while by catch constructor data enum final inline internal open operator override private protected public sealed suspend"),
	"sql":        keywordRegex("select from where join inner left right full outer on group by order having limit offset insert into values update set delete create alter drop table view index primary key foreign references distinct union all as and or not null is like in exists between case when then else end asc desc count sum avg min max with recursive returning"),
	"bash":       keywordRegex("if then else elif fi for while until do done case esac function select in time local export readonly declare unset shift return break continue source alias unalias"),
	"powershell": keywordRegex("begin break catch class continue data do dynamicparam else elseif end enum exit filter finally for foreach from function if in param process return switch throw trap try until using var while workflow parallel sequence"),
	"json":       keywordRegex("true false null"),
	"yaml":       keywordRegex("true false null yes no on off"),
	"toml":       keywordRegex("true false"),
	"html":       keywordRegex("doctype html head body title meta link script style div span p a img ul ol li table thead tbody tr th td form input button section article header footer nav main aside"),
	"xml":        keywordRegex("xml"),
	"css":        keywordRegex("important inherit initial unset auto none block inline flex grid relative absolute fixed sticky hidden visible solid dashed dotted"),
}

var (
	codeStringRegex  = regexp.MustCompile("\\\"(?:\\\\.|[^\\\"\\\\])*\\\"|'(?:\\\\.|[^'\\\\])*'|`[^`]*`")
	codeNumberRegex  = regexp.MustCompile(`\b(?:0x[0-9A-Fa-f]+|0b[01]+|\d+(?:\.\d+)?)\b`)
	codeLiteralRegex = regexp.MustCompile(`\b(?:true|false|null|nil|None|True|False)\b`)
)

func codeCommentIndex(line, lang string) int {
	marker := "//"
	switch lang {
	case "python", "bash", "powershell", "yaml", "toml":
		marker = "#"
	case "sql":
		marker = "--"
	case "html", "xml":
		marker = "<!--"
	case "json":
		return -1
	}
	return strings.Index(line, marker)
}

func appendRegexColorSpans(p *previewBuilder, line string, codeStart int, re *regexp.Regexp, color uint32, bold bool) {
	if re == nil {
		return
	}
	for _, m := range re.FindAllStringIndex(line, -1) {
		st := codeStart + utf16Units(line[:m[0]])
		en := codeStart + utf16Units(line[:m[1]])
		p.span(st, en, previewSpan{colorSet: true, color: color, bold: bold})
	}
}

func highlightCodeLine(p *previewBuilder, line, lang string, codeStart int) {
	lang = normalizeCodeLanguage(lang)
	if lang == "" || lang == "text" || lang == "plain" || lang == "plaintext" {
		return
	}
	c := syntaxColors()
	appendRegexColorSpans(p, line, codeStart, codeKeywordRegex[lang], c.keyword, true)
	appendRegexColorSpans(p, line, codeStart, codeNumberRegex, c.number, false)
	appendRegexColorSpans(p, line, codeStart, codeLiteralRegex, c.literal, true)
	appendRegexColorSpans(p, line, codeStart, codeStringRegex, c.string_, false)
	if idx := codeCommentIndex(line, lang); idx >= 0 {
		st := codeStart + utf16Units(line[:idx])
		en := codeStart + utf16Units(line)
		p.span(st, en, previewSpan{colorSet: true, color: c.comment, italic: true})
	}
}

func headingStyle(level int) previewSpan {
	sizes := []int32{0, 620, 500, 420, 360, 320, 290}
	if level < 1 || level > 6 {
		level = 2
	}
	return previewSpan{bold: true, size: sizes[level], face: "Segoe UI Semibold"}
}

func buildNativePreview(src string) (string, []previewSpan, []previewLink, []previewCodeBlock) {
	src = strings.ReplaceAll(src, "\r\n", "\n")
	lines := strings.Split(src, "\n")
	var p previewBuilder
	for i := 0; i < len(lines); {
		line := lines[i]
		trim := strings.TrimSpace(line)
		if trim == "" {
			p.newline()
			i++
			continue
		}
		if strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~") {
			fence := trim[:3]
			rawLang := strings.TrimSpace(strings.TrimPrefix(trim, fence))
			lang := normalizeCodeLanguage(rawLang)
			i++
			codeLines := make([]string, 0, 8)
			for i < len(lines) && !strings.HasPrefix(strings.TrimSpace(lines[i]), fence) {
				codeLines = append(codeLines, strings.ReplaceAll(lines[i], "\t", "    "))
				i++
			}
			if i < len(lines) {
				i++
			}
			if len(codeLines) == 0 {
				codeLines = []string{""}
			}

			// Reserve vertical space in the RichEdit document, but do not try to fake
			// a rectangular card with character backgrounds. The preview subclass paints
			// a real rounded native code surface over these placeholder rows after RichEdit
			// paints the rest of the Markdown document.
			if p.pos > 0 {
				p.newline()
			}
			blockStart := p.pos
			hidden := previewSpan{face: "Cascadia Mono", size: 220, colorSet: true, color: colors().editorBg}
			for row := 0; row < len(codeLines)+2; row++ {
				st, en := p.raw("\u200B")
				p.span(st, en, hidden)
				p.newline()
			}
			blockEnd := p.pos
			p.blocks = append(p.blocks, previewCodeBlock{
				start: blockStart,
				end:   blockEnd,
				lines: append([]string(nil), codeLines...),
				lang:  lang,
				label: codeLanguageLabel(rawLang, lang),
			})
			p.newline()
			continue
		}
		if i+1 < len(lines) && (reSetext1.MatchString(lines[i+1]) || reSetext2.MatchString(lines[i+1])) {
			level := 2
			if reSetext1.MatchString(lines[i+1]) {
				level = 1
			}
			st := p.pos
			p.inline(trim, headingStyle(level))
			p.span(st, p.pos, headingStyle(level))
			p.newline()
			i += 2
			continue
		}
		if m := reHeading.FindStringSubmatch(line); m != nil {
			lvl := len(m[1])
			st := p.pos
			p.inline(m[2], headingStyle(lvl))
			p.span(st, p.pos, headingStyle(lvl))
			p.newline()
			i++
			continue
		}
		if isTableStart(lines, i) {
			header := splitTableRow(lines[i])
			st := p.pos
			p.inline(strings.Join(header, "    │    "), previewSpan{bold: true})
			p.span(st, p.pos, previewSpan{bold: true})
			p.newline()
			i += 2
			for i < len(lines) && strings.TrimSpace(lines[i]) != "" && strings.Contains(lines[i], "|") {
				p.inline(strings.Join(splitTableRow(lines[i]), "    │    "), previewSpan{})
				p.newline()
				i++
			}
			continue
		}
		if reHR.MatchString(line) {
			st, en := p.raw("────────────────────────────────────────")
			p.span(st, en, previewSpan{colorSet: true, color: colors().muted})
			p.newline()
			i++
			continue
		}
		if strings.HasPrefix(strings.TrimLeft(line, " \t"), ">") {
			body := strings.TrimSpace(strings.TrimPrefix(strings.TrimLeft(line, " \t"), ">"))
			st, en := p.raw("│ ")
			p.span(st, en, previewSpan{colorSet: true, color: colors().accent})
			q := previewSpan{italic: true, colorSet: true, color: colors().muted}
			st = p.pos
			p.inline(body, q)
			p.span(st, p.pos, q)
			p.newline()
			i++
			continue
		}
		if m := reTask.FindStringSubmatch(line); m != nil {
			box := "☐"
			if strings.EqualFold(m[2], "x") {
				box = "☑"
			}
			p.raw(strings.Repeat("  ", len(m[1])/2) + box + "  ")
			p.inline(m[3], previewSpan{})
			p.newline()
			i++
			continue
		}
		if m := reBullet.FindStringSubmatch(line); m != nil {
			p.raw(strings.Repeat("  ", len(m[1])/2) + "•  ")
			p.inline(m[2], previewSpan{})
			p.newline()
			i++
			continue
		}
		if m := reOrdered.FindStringSubmatch(line); m != nil {
			p.raw(strings.Repeat("  ", len(m[1])/2) + m[2] + ".  ")
			p.inline(m[3], previewSpan{})
			p.newline()
			i++
			continue
		}
		if m := reImageLine.FindStringSubmatch(line); m != nil {
			st, en := p.raw("Image: " + m[1] + " — " + m[2])
			p.span(st, en, previewSpan{italic: true, colorSet: true, color: colors().muted})
			p.newline()
			i++
			continue
		}
		p.inline(strings.TrimSpace(line), previewSpan{})
		p.newline()
		i++
	}
	return p.b.String(), p.spans, p.links, p.blocks
}

type codeDrawSegment struct {
	text  string
	color uint32
}

func codeLineSegments(line, lang string) []codeDrawSegment {
	if line == "" {
		return nil
	}
	lang = normalizeCodeLanguage(lang)
	base := colors().text
	c := syntaxColors()
	styles := make([]uint32, len(line))
	prio := make([]byte, len(line))
	for i := range styles {
		styles[i] = base
	}
	paint := func(st, en int, color uint32, priority byte) {
		if st < 0 {
			st = 0
		}
		if en > len(line) {
			en = len(line)
		}
		for i := st; i < en; i++ {
			if priority >= prio[i] {
				prio[i] = priority
				styles[i] = color
			}
		}
	}
	if re := codeKeywordRegex[lang]; re != nil {
		for _, m := range re.FindAllStringIndex(line, -1) {
			paint(m[0], m[1], c.keyword, 1)
		}
	}
	for _, m := range codeNumberRegex.FindAllStringIndex(line, -1) {
		paint(m[0], m[1], c.number, 2)
	}
	for _, m := range codeLiteralRegex.FindAllStringIndex(line, -1) {
		paint(m[0], m[1], c.literal, 3)
	}
	for _, m := range codeStringRegex.FindAllStringIndex(line, -1) {
		paint(m[0], m[1], c.string_, 4)
	}
	if idx := codeCommentIndex(line, lang); idx >= 0 {
		paint(idx, len(line), c.comment, 5)
	}
	out := make([]codeDrawSegment, 0, 8)
	start := 0
	for i := 1; i <= len(line); i++ {
		if i == len(line) || styles[i] != styles[start] {
			out = append(out, codeDrawSegment{text: line[start:i], color: styles[start]})
			start = i
		}
	}
	return out
}

func previewCharPoint(hwnd syscall.Handle, pos int) (POINT, bool) {
	if pos < 0 {
		return POINT{}, false
	}
	// Msftedit/RichEdit 4.x uses the RichEdit 3.0+ EM_POSFROMCHAR form:
	// wParam points at a POINT and lParam carries the character index.
	var pt POINT
	send(hwnd, EM_POSFROMCHAR, uintptr(unsafe.Pointer(&pt)), uintptr(pos))
	return pt, true
}

func paintPreviewBuffered(hwnd syscall.Handle) bool {
	if hwnd == 0 || oldPreviewWndProc == 0 {
		return false
	}
	var ps PAINTSTRUCT
	hdcRaw, _, _ := procBeginPaint.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&ps)))
	if hdcRaw == 0 {
		return false
	}
	defer procEndPaint.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&ps)))

	var client RECT
	procGetClientRect.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&client)))
	w := client.Right - client.Left
	h := client.Bottom - client.Top
	if w <= 0 || h <= 0 {
		return true
	}

	memRaw, _, _ := procCreateCompatibleDC.Call(hdcRaw)
	if memRaw == 0 {
		procCallWindowProc.Call(oldPreviewWndProc, uintptr(hwnd), WM_PRINTCLIENT, hdcRaw, PRF_CLIENT)
		drawPreviewCodeBlocksToDC(hwnd, syscall.Handle(hdcRaw))
		return true
	}
	mem := syscall.Handle(memRaw)
	defer procDeleteDC.Call(memRaw)

	bmpRaw, _, _ := procCreateCompatibleBitmap.Call(hdcRaw, uintptr(w), uintptr(h))
	if bmpRaw == 0 {
		procCallWindowProc.Call(oldPreviewWndProc, uintptr(hwnd), WM_PRINTCLIENT, hdcRaw, PRF_CLIENT)
		drawPreviewCodeBlocksToDC(hwnd, syscall.Handle(hdcRaw))
		return true
	}
	defer procDeleteObject.Call(bmpRaw)
	oldBmp, _, _ := procSelectObject.Call(memRaw, bmpRaw)
	defer procSelectObject.Call(memRaw, oldBmp)

	// Start with the exact preview background, then ask the original RichEdit
	// window procedure to render its client area into the backbuffer. This avoids
	// exposing an intermediate RichEdit-only frame before our custom code cards.
	brush, _, _ := procCreateSolidBrush.Call(uintptr(colors().editorBg))
	if brush != 0 {
		procFillRect.Call(memRaw, uintptr(unsafe.Pointer(&client)), brush)
		procDeleteObject.Call(brush)
	}
	procCallWindowProc.Call(oldPreviewWndProc, uintptr(hwnd), WM_PRINTCLIENT, memRaw, PRF_CLIENT)
	drawPreviewCodeBlocksToDC(hwnd, mem)

	procBitBlt.Call(hdcRaw, 0, 0, uintptr(w), uintptr(h), memRaw, 0, 0, SRCCOPY)
	return true
}

func drawPreviewCodeBlocksToDC(hwnd, hdc syscall.Handle) {
	if hwnd == 0 || hdc == 0 || len(app.previewCodeBlocks) == 0 {
		return
	}

	var client RECT
	procGetClientRect.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&client)))
	p := colors()
	blockBack := rgb(31, 32, 43)
	border := rgb(52, 56, 69)
	shadow := rgb(14, 17, 22)
	if app.cfg.Theme == "light" {
		blockBack = rgb(246, 247, 250)
		border = rgb(218, 222, 230)
		shadow = rgb(232, 234, 239)
	}

	for _, block := range app.previewCodeBlocks {
		startPt, ok := previewCharPoint(hwnd, block.start)
		if !ok {
			continue
		}
		endPt, endOK := previewCharPoint(hwnd, block.end)
		lineH := int32(20)
		height := int32(len(block.lines))*lineH + 42
		if endOK && endPt.Y-startPt.Y > 30 {
			height = endPt.Y - startPt.Y - 2
		}
		top := startPt.Y + 2
		bottom := top + height
		if bottom < 0 || top > client.Bottom {
			continue
		}
		left := int32(18)
		right := client.Right - 18
		if right-left < 180 {
			continue
		}
		r := RECT{Left: left, Top: top, Right: right, Bottom: bottom}
		shadowR := RECT{Left: r.Left + 1, Top: r.Top + 2, Right: r.Right + 1, Bottom: r.Bottom + 2}
		roundFill(hdc, shadowR, shadow, 12)
		roundFill(hdc, r, border, 12)
		inner := RECT{Left: r.Left + 1, Top: r.Top + 1, Right: r.Right - 1, Bottom: r.Bottom - 1}
		roundFill(hdc, inner, blockBack, 11)

		if block.label != "" {
			labelR := RECT{Left: r.Left + 14, Top: r.Top + 4, Right: r.Right - 14, Bottom: r.Top + 22}
			drawText(hdc, block.label, labelR, app.fontSmall, p.muted, DT_RIGHT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
		}
		y := r.Top + 23
		for _, line := range block.lines {
			if y+lineH > r.Bottom-8 {
				break
			}
			x := r.Left + 16
			for _, seg := range codeLineSegments(line, block.lang) {
				if seg.text == "" {
					continue
				}
				if x >= r.Right-12 {
					break
				}
				segW := measureTextWidth(hdc, seg.text, app.fontMono)
				drawR := RECT{Left: x, Top: y, Right: r.Right - 12, Bottom: y + lineH}
				drawText(hdc, seg.text, drawR, app.fontMono, seg.color, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
				x += segW
			}
			y += lineH
		}
	}
}

func applyPreviewSpan(hwnd syscall.Handle, sp previewSpan) {
	if sp.end <= sp.start {
		return
	}
	var cf CHARFORMAT2
	cf.CbSize = uint32(unsafe.Sizeof(cf))
	if sp.bold {
		cf.DwMask |= CFM_BOLD
		cf.DwEffects |= CFE_BOLD
	}
	if sp.italic {
		cf.DwMask |= CFM_ITALIC
		cf.DwEffects |= CFE_ITALIC
	}
	if sp.underline {
		cf.DwMask |= CFM_UNDERLINE
		cf.DwEffects |= CFE_UNDERLINE
	}
	if sp.strike {
		cf.DwMask |= CFM_STRIKEOUT
		cf.DwEffects |= CFE_STRIKEOUT
	}
	if sp.size > 0 {
		cf.DwMask |= CFM_SIZE
		cf.YHeight = sp.size
	}
	if sp.face != "" {
		cf.DwMask |= CFM_FACE
		face := utf16.Encode([]rune(sp.face))
		copy(cf.SzFaceName[:], face)
	}
	if sp.colorSet {
		cf.DwMask |= CFM_COLOR
		cf.CrTextColor = sp.color
	}
	if sp.backSet {
		cf.DwMask |= CFM_BACKCOLOR
		cf.CrBackColor = sp.back
	}
	if cf.DwMask == 0 {
		return
	}
	send(hwnd, EM_SETSEL, uintptr(sp.start), uintptr(sp.end))
	send(hwnd, EM_SETCHARFORMAT, SCF_SELECTION, uintptr(unsafe.Pointer(&cf)))
}

func applyPreviewLink(hwnd syscall.Handle, l previewLink) {
	if l.end <= l.start {
		return
	}
	var cf CHARFORMAT2
	cf.CbSize = uint32(unsafe.Sizeof(cf))
	cf.DwMask = CFM_LINK
	cf.DwEffects = CFE_LINK
	send(hwnd, EM_SETSEL, uintptr(l.start), uintptr(l.end))
	send(hwnd, EM_SETCHARFORMAT, SCF_SELECTION, uintptr(unsafe.Pointer(&cf)))
}

func renderNativePreview(hwnd syscall.Handle, src string) {
	text, spans, links, blocks := buildNativePreview(src)
	p := colors()

	// SetWindowTextW resets a RichEdit viewport to the top. Live Split/Preview
	// rendering therefore used to yank the reader back to line 1 on every edit.
	// Capture the exact pixel scroll position before replacing the document and
	// restore it after all formatting has been applied.
	var savedScroll POINT
	send(hwnd, EM_GETSCROLLPOS, 0, uintptr(unsafe.Pointer(&savedScroll)))

	// Keep intermediate selection/formatting operations off-screen, then repaint once.
	send(hwnd, WM_SETREDRAW, 0, 0)
	defer func() {
		send(hwnd, EM_SETSEL, 0, 0)
		send(hwnd, EM_SETSCROLLPOS, 0, uintptr(unsafe.Pointer(&savedScroll)))
		send(hwnd, WM_SETREDRAW, 1, 0)
		procInvalidateRect.Call(uintptr(hwnd), 0, 0)
	}()

	setText(hwnd, text)
	logicalLen := richEditSelectionUnits(text)
	var base CHARFORMAT2
	base.CbSize = uint32(unsafe.Sizeof(base))
	base.DwMask = CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE | CFM_STRIKEOUT | CFM_BACKCOLOR | CFM_LINK
	base.CrTextColor = p.text
	base.CrBackColor = p.editorBg
	base.YHeight = 250
	copy(base.SzFaceName[:], utf16.Encode([]rune("Segoe UI")))
	base.DwEffects = 0
	send(hwnd, EM_SETCHARFORMAT, SCF_ALL, uintptr(unsafe.Pointer(&base)))
	for _, sp := range spans {
		// Never let a malformed parser range bleed into later content. RichEdit
		// silently accepts overlong selections, which can make subsequent text
		// inherit heading/code formatting in surprising ways.
		if sp.start < 0 {
			sp.start = 0
		}
		if sp.end > logicalLen {
			sp.end = logicalLen
		}
		if sp.start > logicalLen {
			continue
		}
		applyPreviewSpan(hwnd, sp)
	}
	app.previewLinks = app.previewLinks[:0]
	app.previewCodeBlocks = append(app.previewCodeBlocks[:0], blocks...)
	for _, l := range links {
		if l.start < 0 {
			l.start = 0
		}
		if l.end > logicalLen {
			l.end = logicalLen
		}
		if l.end <= l.start || l.start > logicalLen {
			continue
		}
		applyPreviewLink(hwnd, l)
		app.previewLinks = append(app.previewLinks, l)
	}
	send(hwnd, EM_SETREADONLY, 1, 0)
}
