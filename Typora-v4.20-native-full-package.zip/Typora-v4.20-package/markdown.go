//go:build windows

package main

import (
	"bytes"
	"encoding/hex"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"unicode/utf16"
	"unicode/utf8"
)

func rtfColorTable(dark bool) string {
	if dark {
		return `{\colortbl ;\red236\green238\blue243;\red150\green157\blue171;\red106\green155\blue255;\red47\green51\blue62;\red33\green37\blue46;\red39\green43\blue53;\red91\green201\blue136;}`
	}
	return `{\colortbl ;\red34\green37\blue44;\red112\green118\blue130;\red70\green103\blue220;\red242\green243\blue247;\red246\green247\blue250;\red236\green238\blue244;\red26\green145\blue85;}`
}

func rtfHeader(dark bool) string {
	ct := rtfColorTable(dark)
	return `{\rtf1\ansi\deff0\uc1{\fonttbl{\f0 Segoe UI;}{\f1 Cascadia Mono;}{\f2 Segoe UI Semibold;}}` + ct + `\viewkind4\pard\sa140\sl300\slmult1\cf1\f0\fs23 `
}

func rtfEscape(s string) string {
	var b strings.Builder
	for _, r := range s {
		switch r {
		case '\\', '{', '}':
			b.WriteByte('\\')
			b.WriteRune(r)
		case '\t':
			b.WriteString(`\tab `)
		case '\n':
			b.WriteString(`\line `)
		case '\r':
		default:
			if r >= 32 && r <= 126 {
				b.WriteRune(r)
			} else {
				for _, u := range utf16.Encode([]rune{r}) {
					b.WriteString(fmt.Sprintf(`\u%d?`, int16(u)))
				}
			}
		}
	}
	return b.String()
}

func inlineRTF(s string) string {
	var b strings.Builder
	for len(s) > 0 {
		if strings.HasPrefix(s, "\\") && len(s) > 1 {
			_, sz := utf8.DecodeRuneInString(s[1:])
			b.WriteString(rtfEscape(s[1 : 1+sz]))
			s = s[1+sz:]
			continue
		}
		if strings.HasPrefix(s, "![") {
			if close := strings.Index(s, "]("); close >= 2 {
				if end := strings.Index(s[close+2:], ")"); end >= 0 {
					alt := s[2:close]
					target := s[close+2 : close+2+end]
					b.WriteString(`{\cf3 ` + rtfEscape("Image: "+alt+" — "+target) + `}`)
					s = s[close+3+end:]
					continue
				}
			}
		}
		if strings.HasPrefix(s, "[") {
			if close := strings.Index(s, "]("); close >= 1 {
				if end := strings.Index(s[close+2:], ")"); end >= 0 {
					label := s[1:close]
					target := s[close+2 : close+2+end]
					safe := strings.ReplaceAll(strings.ReplaceAll(target, "\\", "/"), `"`, `\"`)
					b.WriteString(`{\field{\*\fldinst{HYPERLINK "` + rtfEscape(safe) + `"}}{\fldrslt{\ul\cf3 ` + inlineRTF(label) + `}}}`)
					s = s[close+3+end:]
					continue
				}
			}
		}
		if strings.HasPrefix(s, "**") || strings.HasPrefix(s, "__") {
			mark := s[:2]
			if j := strings.Index(s[2:], mark); j >= 0 {
				inner := s[2 : 2+j]
				b.WriteString(`{\b ` + inlineRTF(inner) + `}`)
				s = s[4+j:]
				continue
			}
		}
		if strings.HasPrefix(s, "~~") {
			if j := strings.Index(s[2:], "~~"); j >= 0 {
				inner := s[2 : 2+j]
				b.WriteString(`{\strike ` + inlineRTF(inner) + `}`)
				s = s[4+j:]
				continue
			}
		}
		if strings.HasPrefix(s, "`") {
			if j := strings.Index(s[1:], "`"); j >= 0 {
				inner := s[1 : 1+j]
				b.WriteString(`{\f1\fs20\highlight4 ` + rtfEscape(inner) + `\highlight0\f0\fs23}`)
				s = s[2+j:]
				continue
			}
		}
		if strings.HasPrefix(s, "*") || strings.HasPrefix(s, "_") {
			mark := s[:1]
			if j := strings.Index(s[1:], mark); j > 0 {
				inner := s[1 : 1+j]
				b.WriteString(`{\i ` + inlineRTF(inner) + `}`)
				s = s[2+j:]
				continue
			}
		}
		r, sz := utf8.DecodeRuneInString(s)
		if sz == 0 {
			break
		}
		b.WriteString(rtfEscape(string(r)))
		s = s[sz:]
	}
	return b.String()
}

var (
	reHeading   = regexp.MustCompile(`^(#{1,6})\s+(.+?)\s*#*\s*$`)
	reTask      = regexp.MustCompile(`^(\s*)[-+*]\s+\[([ xX])\]\s+(.*)$`)
	reBullet    = regexp.MustCompile(`^(\s*)[-+*]\s+(.*)$`)
	reOrdered   = regexp.MustCompile(`^(\s*)(\d+)[.)]\s+(.*)$`)
	reImageLine = regexp.MustCompile(`^\s*!\[([^\]]*)\]\(([^)]+)\)\s*$`)
	reSetext1   = regexp.MustCompile(`^\s*=+\s*$`)
	reSetext2   = regexp.MustCompile(`^\s*-+\s*$`)
	reHR        = regexp.MustCompile(`^\s*((\*\s*){3,}|(-\s*){3,}|(_\s*){3,})\s*$`)
)

func markdownToRTF(src, baseDir string, dark bool) string {
	src = strings.ReplaceAll(src, "\r\n", "\n")
	lines := strings.Split(src, "\n")
	var b strings.Builder
	b.WriteString(rtfHeader(dark))
	for i := 0; i < len(lines); {
		line := lines[i]
		trim := strings.TrimSpace(line)
		if trim == "" {
			b.WriteString(`\pard\sa80\par `)
			i++
			continue
		}
		if strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~") {
			fence := trim[:3]
			lang := strings.TrimSpace(strings.TrimPrefix(trim, fence))
			i++
			var code []string
			for i < len(lines) && !strings.HasPrefix(strings.TrimSpace(lines[i]), fence) {
				code = append(code, lines[i])
				i++
			}
			if i < len(lines) {
				i++
			}
			b.WriteString(`\pard\sb120\sa40\cf2\fs18 ` + rtfEscape(strings.ToUpper(lang)) + `\par `)
			b.WriteString(`\pard\li180\ri180\sb0\sa0\f1\fs19\highlight4 `)
			for j, c := range code {
				b.WriteString(rtfEscape(c))
				if j < len(code)-1 {
					b.WriteString(`\line `)
				}
			}
			b.WriteString(`\highlight0\f0\cf1\fs23\par\pard `)
			continue
		}
		if m := reImageLine.FindStringSubmatch(line); m != nil {
			if pic, ok := imageBlockRTF(baseDir, m[2], m[1]); ok {
				b.WriteString(pic)
			} else {
				b.WriteString(`\pard\qc\sa160\cf2 ` + rtfEscape("Image: "+m[1]+" — "+m[2]) + `\par`)
			}
			i++
			continue
		}
		if i+1 < len(lines) && trim != "" && (reSetext1.MatchString(lines[i+1]) || reSetext2.MatchString(lines[i+1])) {
			size := 36
			if reSetext1.MatchString(lines[i+1]) {
				size = 44
			}
			b.WriteString(fmt.Sprintf(`\pard\sb180\sa100\f2\b\fs%d\cf1 %s\b0\f0\fs23\par`, size, inlineRTF(trim)))
			i += 2
			continue
		}
		if m := reHeading.FindStringSubmatch(line); m != nil {
			sizes := []int{0, 44, 36, 30, 26, 24, 22}
			b.WriteString(fmt.Sprintf(`\pard\sb180\sa100\f2\b\fs%d\cf1 %s\b0\f0\fs23\par`, sizes[len(m[1])], inlineRTF(m[2])))
			i++
			continue
		}
		if isTableStart(lines, i) {
			i = writeTableRTF(&b, lines, i)
			continue
		}
		if reHR.MatchString(line) {
			b.WriteString(`\pard\qc\sa160\cf2 ` + rtfEscape("────────────────────────────────────────") + `\par`)
			i++
			continue
		}
		if strings.HasPrefix(strings.TrimLeft(line, " \t"), ">") {
			var q []string
			for i < len(lines) {
				t := strings.TrimSpace(lines[i])
				if !strings.HasPrefix(t, ">") {
					break
				}
				q = append(q, strings.TrimSpace(strings.TrimPrefix(t, ">")))
				i++
			}
			b.WriteString(`\pard\li360\ri180\sb80\sa100\highlight5\i\cf2 ` + inlineRTF(strings.Join(q, " ")) + `\highlight0\i0\cf1\par`)
			continue
		}
		if m := reTask.FindStringSubmatch(line); m != nil {
			indent := len(m[1]) / 2
			box := "☐"
			if strings.ToLower(m[2]) == "x" {
				box = "☑"
			}
			b.WriteString(fmt.Sprintf(`\pard\li%d\fi-260\sa60 %s\tab %s\par`, 360+indent*280, rtfEscape(box), inlineRTF(m[3])))
			i++
			continue
		}
		if m := reBullet.FindStringSubmatch(line); m != nil {
			indent := len(m[1]) / 2
			b.WriteString(fmt.Sprintf(`\pard\li%d\fi-260\sa60 %s\tab %s\par`, 360+indent*280, rtfEscape("•"), inlineRTF(m[2])))
			i++
			continue
		}
		if m := reOrdered.FindStringSubmatch(line); m != nil {
			indent := len(m[1]) / 2
			b.WriteString(fmt.Sprintf(`\pard\li%d\fi-300\sa60 %s.\tab %s\par`, 380+indent*280, rtfEscape(m[2]), inlineRTF(m[3])))
			i++
			continue
		}
		var para []string
		for i < len(lines) {
			t := lines[i]
			if strings.TrimSpace(t) == "" || isSpecialBlock(lines, i) {
				break
			}
			para = append(para, strings.TrimSpace(t))
			i++
		}
		if len(para) == 0 {
			para = []string{trim}
			i++
		}
		b.WriteString(`\pard\sa140\cf1\f0\fs23 ` + inlineRTF(strings.Join(para, " ")) + `\par`)
	}
	b.WriteString(`}`)
	return b.String()
}

func isSpecialBlock(lines []string, i int) bool {
	if i >= len(lines) {
		return false
	}
	line := lines[i]
	trim := strings.TrimSpace(line)
	if trim == "" || strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~") || reHeading.MatchString(line) || reTask.MatchString(line) || reBullet.MatchString(line) || reOrdered.MatchString(line) || reImageLine.MatchString(line) || reHR.MatchString(line) || strings.HasPrefix(strings.TrimLeft(line, " \t"), ">") {
		return true
	}
	if isTableStart(lines, i) {
		return true
	}
	return i+1 < len(lines) && (reSetext1.MatchString(lines[i+1]) || reSetext2.MatchString(lines[i+1]))
}
func splitTableRow(s string) []string {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, "|")
	s = strings.TrimSuffix(s, "|")
	p := strings.Split(s, "|")
	for i := range p {
		p[i] = strings.TrimSpace(p[i])
	}
	return p
}
func isTableStart(lines []string, i int) bool {
	if i+1 >= len(lines) || !strings.Contains(lines[i], "|") {
		return false
	}
	cells := splitTableRow(lines[i+1])
	if len(cells) < 2 {
		return false
	}
	for _, c := range cells {
		c = strings.Trim(strings.TrimSpace(c), ":")
		if len(c) < 3 || strings.Trim(c, "-") != "" {
			return false
		}
	}
	return true
}
func writeTableRTF(b *strings.Builder, lines []string, i int) int {
	head := splitTableRow(lines[i])
	i += 2
	rows := [][]string{head}
	for i < len(lines) && strings.Contains(lines[i], "|") && strings.TrimSpace(lines[i]) != "" {
		rows = append(rows, splitTableRow(lines[i]))
		i++
	}
	n := len(head)
	if n == 0 {
		return i
	}
	width := 9000 / n
	for ri, row := range rows {
		b.WriteString(`\trowd\trgaph80\trleft0 `)
		for c := 0; c < n; c++ {
			if ri == 0 {
				b.WriteString(`\clcbpat6 `)
			}
			b.WriteString(fmt.Sprintf(`\cellx%d `, (c+1)*width))
		}
		for c := 0; c < n; c++ {
			txt := ""
			if c < len(row) {
				txt = row[c]
			}
			b.WriteString(`\intbl\fs20 `)
			if ri == 0 {
				b.WriteString(`\b `)
			}
			b.WriteString(inlineRTF(txt))
			if ri == 0 {
				b.WriteString(`\b0 `)
			}
			b.WriteString(`\cell `)
		}
		b.WriteString(`\row `)
	}
	b.WriteString(`\pard\sa140\par `)
	return i
}
func imageBlockRTF(baseDir, target, alt string) (string, bool) {
	target = strings.TrimSpace(strings.Trim(target, "<>"))
	if strings.HasPrefix(target, "http://") || strings.HasPrefix(target, "https://") {
		return "", false
	}
	path := target
	if !filepath.IsAbs(path) {
		path = filepath.Join(baseDir, path)
	}
	data, err := os.ReadFile(path)
	if err != nil || len(data) > 8*1024*1024 {
		return "", false
	}
	cfg, format, err := image.DecodeConfig(bytes.NewReader(data))
	if err != nil || (format != "png" && format != "jpeg") {
		return "", false
	}
	blip := "pngblip"
	if format == "jpeg" {
		blip = "jpegblip"
	}
	w, h := cfg.Width, cfg.Height
	if w <= 0 || h <= 0 {
		return "", false
	}
	scale := 1.0
	if w > 720 {
		scale = 720.0 / float64(w)
	}
	wg := int(float64(w) * 15 * scale)
	hg := int(float64(h) * 15 * scale)
	hexdata := hex.EncodeToString(data)
	caption := ""
	if strings.TrimSpace(alt) != "" {
		caption = `\par\cf2\fs18 ` + rtfEscape(alt)
	}
	return fmt.Sprintf(`\pard\qc\sa120{\pict\%s\picw%d\pich%d\picwgoal%d\pichgoal%d %s}%s\cf1\fs23\par`, blip, w, h, wg, hg, hexdata, caption), true
}
